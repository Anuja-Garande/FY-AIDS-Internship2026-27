<?php
require_once __DIR__ . '/config/db_connect.php';

$pdo = getDB();
$hash = password_hash('Password123', PASSWORD_BCRYPT);

$stmt = $pdo->prepare("UPDATE Users SET Password_Hash = ?");
$stmt->execute([$hash]);

echo "SUCCESS: Updated " . $stmt->rowCount() . " user passwords.\n";

$stmtCheck = $pdo->prepare("SELECT * FROM Users WHERE Email = ?");
$stmtCheck->execute(['alex.j@student.sppi.edu']);
$user = $stmtCheck->fetch();

if ($user && password_verify('Password123', $user['Password_Hash'])) {
    echo "VERIFICATION PASSED: password_verify('Password123') returns TRUE for " . $user['Email'] . "!\n";
} else {
    echo "VERIFICATION FAILED!\n";
}
?>
