<?php
// company/manage_listings.php - Manage Company Internship Listings
require_once __DIR__ . '/../config/db_connect.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_role('Company');
$user = get_logged_in_user();
$pdo = getDB();

$companyId = $_SESSION['company_id'] ?? 0;

// Toggle status action if requested
if (isset($_GET['toggle_status_id'])) {
    $toggleId = (int)$_GET['toggle_status_id'];
    $stmtT = $pdo->prepare("SELECT Status FROM Internships WHERE Internship_ID = ? AND Company_ID = ?");
    $stmtT->execute([$toggleId, $companyId]);
    $curr = $stmtT->fetch();

    if ($curr) {
        $newStatus = ($curr['Status'] === 'Open') ? 'Closed' : 'Open';
        $stmtUp = $pdo->prepare("UPDATE Internships SET Status = ? WHERE Internship_ID = ?");
        $stmtUp->execute([$newStatus, $toggleId]);
        set_flash_message('success', "Listing status updated to '$newStatus'.");
        header('Location: manage_listings.php');
        exit();
    }
}

// Fetch Listings with total applicant count
$stmtListings = $pdo->prepare("
    SELECT i.*, 
           (SELECT COUNT(*) FROM Applications WHERE Internship_ID = i.Internship_ID) as Total_Applicants
    FROM Internships i
    WHERE i.Company_ID = ?
    ORDER BY i.Posted_Date DESC
");
$stmtListings->execute([$companyId]);
$listings = $stmtListings->fetchAll();

$page_title = "Manage Internship Listings - Company Portal";
$active_page = "listings";
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
    <div>
        <h1 class="page-title">Manage Internship Listings</h1>
        <p class="page-subtitle">Create, update, or close internship opportunities posted by your organization</p>
    </div>
    <div>
        <a href="post_internship.php" class="btn btn-primary">➕ Post New Opening</a>
    </div>
</div>

<?php if (empty($listings)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📋</div>
        <div class="empty-state-title">No Listings Posted Yet</div>
        <p class="empty-state-desc">You have not created any internship openings yet.</p>
        <a href="post_internship.php" class="btn btn-primary">Post First Opening</a>
    </div>
<?php else: ?>
    <div class="table-responsive">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Listing Title</th>
                    <th>Required Skills</th>
                    <th>Duration</th>
                    <th>Total Applicants</th>
                    <th>Posted Date</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($listings as $item): ?>
                    <tr>
                        <td>
                            <strong><?= sanitize($item['Title']) ?></strong>
                        </td>
                        <td style="font-size: 0.85rem; color: var(--text-muted); max-width: 220px;">
                            <?= sanitize($item['Required_Skills']) ?>
                        </td>
                        <td style="font-size: 0.85rem;">
                            <?= (int)$item['Duration_Weeks'] ?> Weeks
                        </td>
                        <td>
                            <a href="view_applicants.php?listing_id=<?= $item['Internship_ID'] ?>" style="font-weight: 600;">
                                👥 <?= (int)$item['Total_Applicants'] ?> Candidate(s)
                            </a>
                        </td>
                        <td style="font-size: 0.85rem; color: var(--text-muted);">
                            <?= date('M d, Y', strtotime($item['Posted_Date'])) ?>
                        </td>
                        <td>
                            <?= render_status_badge($item['Status']) ?>
                        </td>
                        <td style="white-space: nowrap;">
                            <a href="post_internship.php?edit_id=<?= $item['Internship_ID'] ?>" class="btn btn-sm btn-outline">✏️ Edit</a>
                            <a href="manage_listings.php?toggle_status_id=<?= $item['Internship_ID'] ?>" class="btn btn-sm btn-secondary" style="margin-left: 0.25rem;">
                                <?= $item['Status'] === 'Open' ? '🔒 Close' : '🔓 Re-open' ?>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
