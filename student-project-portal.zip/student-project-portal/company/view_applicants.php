<?php
// company/view_applicants.php - Recruiter Candidate Review & Selection
require_once __DIR__ . '/../config/db_connect.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_role('Company');
$user = get_logged_in_user();
$pdo = getDB();

$companyId = $_SESSION['company_id'] ?? 0;

$listingIdFilter = (int)($_GET['listing_id'] ?? 0);
$statusFilter    = trim($_GET['status'] ?? 'all');

// Process Status Update Action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action_update_status'])) {
    $targetAppId = (int)$_POST['app_id'];
    $newStatus   = trim($_POST['new_status']);

    $validStatuses = ['Approved', 'Shortlisted', 'Selected', 'Rejected'];

    if (in_array($newStatus, $validStatuses)) {
        // Ensure application belongs to this company's listing
        $stmtVerify = $pdo->prepare("
            SELECT a.Application_ID 
            FROM Applications a
            JOIN Internships i ON a.Internship_ID = i.Internship_ID
            WHERE a.Application_ID = ? AND i.Company_ID = ?
        ");
        $stmtVerify->execute([$targetAppId, $companyId]);

        if ($stmtVerify->fetch()) {
            $stmtUp = $pdo->prepare("UPDATE Applications SET Status = ? WHERE Application_ID = ?");
            $stmtUp->execute([$newStatus, $targetAppId]);
            set_flash_message('success', "Candidate status updated to '$newStatus'.");
            header('Location: view_applicants.php?' . $_SERVER['QUERY_STRING']);
            exit();
        }
    }
}

// Build SQL Query
$query = "
    SELECT a.*, i.Title as Position_Title, u.Full_Name as Student_Name, u.Email as Student_Email,
           s.Department, s.Current_Semester, s.Skills as Student_Skills, s.Resume_Path,
           mf.Remarks as Mentor_Remarks, mentorUser.Full_Name as Mentor_Name
    FROM Applications a
    JOIN Internships i ON a.Internship_ID = i.Internship_ID
    JOIN Students s ON a.Student_ID = s.Student_ID
    JOIN Users u ON s.User_ID = u.User_ID
    LEFT JOIN Mentor_Feedback mf ON a.Application_ID = mf.Application_ID
    LEFT JOIN Users mentorUser ON s.Mentor_User_ID = mentorUser.User_ID
    WHERE i.Company_ID = ?
";
$params = [$companyId];

if ($listingIdFilter > 0) {
    $query .= " AND a.Internship_ID = ?";
    $params[] = $listingIdFilter;
}

if ($statusFilter !== 'all') {
    $query .= " AND a.Status = ?";
    $params[] = $statusFilter;
}

$query .= " ORDER BY a.Applied_Date DESC";

$stmtApps = $pdo->prepare($query);
$stmtApps->execute($params);
$applicants = $stmtApps->fetchAll();

// Fetch company listings for dropdown filter
$stmtCompanyListings = $pdo->prepare("SELECT Internship_ID, Title FROM Internships WHERE Company_ID = ?");
$stmtCompanyListings->execute([$companyId]);
$companyListings = $stmtCompanyListings->fetchAll();

$page_title = "View Applicants - Company Portal";
$active_page = "applicants";
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
    <div>
        <h1 class="page-title">Candidate Applicants</h1>
        <p class="page-subtitle">Review faculty-verified student candidates and update recruitment stage</p>
    </div>
</div>

<!-- Filter Bar -->
<div class="card" style="margin-bottom: 2rem;">
    <div class="card-body" style="padding: 1rem 1.25rem;">
        <form action="view_applicants.php" method="GET" style="display: flex; gap: 1rem; flex-wrap: wrap;">
            <div style="flex: 1; min-width: 200px;">
                <label class="form-label" style="font-size: 0.8rem;">Filter by Opening</label>
                <select name="listing_id" class="form-select">
                    <option value="0">-- All Internship Positions --</option>
                    <?php foreach ($companyListings as $cList): ?>
                        <option value="<?= $cList['Internship_ID'] ?>" <?= $listingIdFilter == $cList['Internship_ID'] ? 'selected' : '' ?>>
                            <?= sanitize($cList['Title']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div style="flex: 1; min-width: 180px;">
                <label class="form-label" style="font-size: 0.8rem;">Filter by Stage</label>
                <select name="status" class="form-select">
                    <option value="all" <?= $statusFilter === 'all' ? 'selected' : '' ?>>All Stages</option>
                    <option value="Approved" <?= $statusFilter === 'Approved' ? 'selected' : '' ?>>Faculty Approved</option>
                    <option value="Shortlisted" <?= $statusFilter === 'Shortlisted' ? 'selected' : '' ?>>Shortlisted</option>
                    <option value="Selected" <?= $statusFilter === 'Selected' ? 'selected' : '' ?>>Selected / Hired</option>
                    <option value="Submitted" <?= $statusFilter === 'Submitted' ? 'selected' : '' ?>>Pending Mentor Review</option>
                    <option value="Rejected" <?= $statusFilter === 'Rejected' ? 'selected' : '' ?>>Rejected</option>
                </select>
            </div>

            <div style="align-self: flex-end;">
                <button type="submit" class="btn btn-primary">Apply Filters</button>
                <a href="view_applicants.php" class="btn btn-secondary">Reset</a>
            </div>
        </form>
    </div>
</div>

<!-- Applicants Cards / List -->
<?php if (empty($applicants)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">👥</div>
        <div class="empty-state-title">No Candidate Applicants Found</div>
        <p class="empty-state-desc">There are no student applications matching your selected position or status filter.</p>
    </div>
<?php else: ?>
    <div style="display: flex; flex-direction: column; gap: 1.5rem;">
        <?php foreach ($applicants as $cand): ?>
            <div class="card">
                <div class="card-header">
                    <div>
                        <span class="badge badge-info" style="margin-bottom: 0.25rem;"><?= sanitize($cand['Position_Title']) ?></span>
                        <h3 class="card-title" style="font-size: 1.2rem;"><?= sanitize($cand['Student_Name']) ?></h3>
                        <p style="font-size: 0.85rem; color: var(--text-muted); margin-top: 0.15rem;">
                            <?= sanitize($cand['Department']) ?> • Semester <?= (int)$cand['Current_Semester'] ?> • <?= sanitize($cand['Student_Email']) ?>
                        </p>
                    </div>
                    <div style="text-align: right;">
                        <span style="font-size: 0.8rem; color: var(--text-muted); display: block; margin-bottom: 0.25rem;">Stage:</span>
                        <?= render_status_badge($cand['Status']) ?>
                    </div>
                </div>

                <div class="card-body">
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1.5rem; margin-bottom: 1.25rem;">
                        
                        <!-- Skills & Resume -->
                        <div>
                            <strong style="font-size: 0.85rem; color: var(--text-muted); display: block; margin-bottom: 0.35rem;">Technical Skills:</strong>
                            <div style="font-size: 0.9rem; color: var(--primary-900); background: var(--surface-alt); padding: 0.6rem 0.8rem; border-radius: 6px; margin-bottom: 0.75rem;">
                                🛠️ <?= sanitize($cand['Student_Skills'] ?? 'No skills listed') ?>
                            </div>

                            <strong style="font-size: 0.85rem; color: var(--text-muted); display: block; margin-bottom: 0.35rem;">Resume Document:</strong>
                            <?php if (!empty($cand['Resume_Path'])): ?>
                                <a href="<?= get_base_url() . sanitize($cand['Resume_Path']) ?>" target="_blank" class="btn btn-sm btn-outline">
                                    📄 View Candidate Resume PDF
                                </a>
                            <?php else: ?>
                                <span style="font-size: 0.85rem; color: var(--danger-600);">No Resume Uploaded</span>
                            <?php endif; ?>
                        </div>

                        <!-- Faculty Mentor Remarks -->
                        <div>
                            <strong style="font-size: 0.85rem; color: var(--text-muted); display: block; margin-bottom: 0.35rem;">Faculty Mentor Verification:</strong>
                            <?php if (!empty($cand['Mentor_Remarks'])): ?>
                                <div style="background-color: var(--accent-50); border-left: 3px solid var(--accent-600); padding: 0.6rem 0.8rem; border-radius: 0 6px 6px 0; font-size: 0.85rem;">
                                    <strong style="color: var(--accent-600);">Mentor: <?= sanitize($cand['Mentor_Name'] ?? 'Faculty') ?></strong><br>
                                    "<?= sanitize($cand['Mentor_Remarks']) ?>"
                                </div>
                            <?php else: ?>
                                <span style="font-size: 0.85rem; color: var(--text-muted); italic;">Pending mentor comments</span>
                            <?php endif; ?>
                        </div>

                    </div>

                    <hr style="border: none; border-top: 1px solid var(--border-color); margin: 1rem 0;">

                    <!-- Candidate Selection Status Action Form -->
                    <form action="view_applicants.php?<?= $_SERVER['QUERY_STRING'] ?>" method="POST" style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 1rem;">
                        <input type="hidden" name="action_update_status" value="1">
                        <input type="hidden" name="app_id" value="<?= (int)$cand['Application_ID'] ?>">

                        <div style="font-size: 0.85rem; color: var(--text-muted);">
                            Applied On: <strong><?= date('M d, Y', strtotime($cand['Applied_Date'])) ?></strong>
                        </div>

                        <div style="display: flex; align-items: center; gap: 0.75rem;">
                            <label style="font-size: 0.85rem; font-weight: 600;">Update Stage:</label>
                            <select name="new_status" class="form-select" style="width: auto; padding: 0.35rem 0.75rem; font-size: 0.85rem;">
                                <option value="Approved" <?= $cand['Status'] === 'Approved' ? 'selected' : '' ?>>Approved (Faculty Verified)</option>
                                <option value="Shortlisted" <?= $cand['Status'] === 'Shortlisted' ? 'selected' : '' ?>>⭐ Shortlisted</option>
                                <option value="Selected" <?= $cand['Status'] === 'Selected' ? 'selected' : '' ?>>🎉 Selected / Hired</option>
                                <option value="Rejected" <?= $cand['Status'] === 'Rejected' ? 'selected' : '' ?>>❌ Rejected</option>
                            </select>
                            <button type="submit" class="btn btn-sm btn-primary">Update Status</button>
                        </div>
                    </form>

                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
