<?php
// company/post_internship.php - Post or Edit Internship Opening
require_once __DIR__ . '/../config/db_connect.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_role('Company');
$user = get_logged_in_user();
$pdo = getDB();

$companyId = $_SESSION['company_id'] ?? 0;

$editId = (int)($_GET['edit_id'] ?? 0);
$isEdit = false;

$title = '';
$description = '';
$skills = '';
$duration = 8;
$status = 'Open';
$error = '';

if ($editId > 0) {
    $stmtEdit = $pdo->prepare("SELECT * FROM Internships WHERE Internship_ID = ? AND Company_ID = ?");
    $stmtEdit->execute([$editId, $companyId]);
    $existing = $stmtEdit->fetch();

    if ($existing) {
        $isEdit = true;
        $title = $existing['Title'];
        $description = $existing['Description'];
        $skills = $existing['Required_Skills'];
        $duration = $existing['Duration_Weeks'];
        $status = $existing['Status'];
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $skills = trim($_POST['skills'] ?? '');
    $duration = (int)($_POST['duration'] ?? 8);
    $status = trim($_POST['status'] ?? 'Open');

    if (empty($title)) $error = "Job Title is required.";
    elseif (empty($description)) $error = "Job Description is required.";
    elseif (empty($skills)) $error = "Required Skills are required.";
    elseif ($duration < 1) $error = "Duration must be at least 1 week.";
    else {
        try {
            if ($isEdit) {
                $stmtUpdate = $pdo->prepare("
                    UPDATE Internships 
                    SET Title = ?, Description = ?, Required_Skills = ?, Duration_Weeks = ?, Status = ?
                    WHERE Internship_ID = ? AND Company_ID = ?
                ");
                $stmtUpdate->execute([$title, $description, $skills, $duration, $status, $editId, $companyId]);
                set_flash_message('success', 'Internship listing updated successfully!');
            } else {
                $stmtInsert = $pdo->prepare("
                    INSERT INTO Internships (Company_ID, Title, Description, Required_Skills, Duration_Weeks, Status, Posted_Date)
                    VALUES (?, ?, ?, ?, ?, ?, NOW())
                ");
                $stmtInsert->execute([$companyId, $title, $description, $skills, $duration, $status]);
                set_flash_message('success', 'New internship opening posted successfully!');
            }

            header('Location: manage_listings.php');
            exit();
        } catch (Exception $e) {
            $error = "Failed to save listing: " . $e->getMessage();
        }
    }
}

$page_title = ($isEdit ? "Edit Listing" : "Post New Internship") . " - Company Portal";
$active_page = "post";
require_once __DIR__ . '/../includes/header.php';
?>

<div style="max-width: 760px; margin: 2rem auto;">
    <div class="card">
        <div class="card-header">
            <h1 class="card-title" style="font-size: 1.3rem;"><?= $isEdit ? "Edit Internship Listing" : "Post New Internship Opening" ?></h1>
        </div>

        <div class="card-body">
            <?php if ($error): ?>
                <div class="alert alert-danger"><?= sanitize($error) ?></div>
            <?php endif; ?>

            <form action="<?= $isEdit ? 'post_internship.php?edit_id=' . $editId : 'post_internship.php' ?>" method="POST" data-validate>
                
                <div class="form-group">
                    <label class="form-label" for="title">Internship Position Title *</label>
                    <input type="text" id="title" name="title" class="form-control" value="<?= sanitize($title) ?>" placeholder="e.g. Backend Software Engineer Intern" required>
                </div>

                <div class="form-group">
                    <label class="form-label" for="description">Detailed Job Description & Responsibilities *</label>
                    <textarea id="description" name="description" class="form-control" rows="5" placeholder="Describe the internship scope, project goals, learning outcomes, and day-to-day tasks..." required><?= sanitize($description) ?></textarea>
                </div>

                <div class="form-group">
                    <label class="form-label" for="skills">Required Skills & Frameworks *</label>
                    <input type="text" id="skills" name="skills" class="form-control" value="<?= sanitize($skills) ?>" placeholder="e.g. PHP, MySQL, JavaScript, HTML5/CSS3, Git" required>
                    <span class="form-text">List key technical competencies expected from applicants.</span>
                </div>

                <div class="form-group">
                    <label class="form-label" for="duration">Duration (in Weeks) *</label>
                    <input type="number" id="duration" name="duration" class="form-control" value="<?= (int)$duration ?>" min="1" max="52" required>
                </div>

                <div class="form-group">
                    <label class="form-label" for="status">Listing Status *</label>
                    <select id="status" name="status" class="form-select" required>
                        <option value="Open" <?= $status === 'Open' ? 'selected' : '' ?>>Open (Accepting Applications)</option>
                        <option value="Closed" <?= $status === 'Closed' ? 'selected' : '' ?>>Closed (Not Accepting New Applications)</option>
                    </select>
                </div>

                <div style="display: flex; gap: 1rem; justify-content: flex-end; margin-top: 1.5rem;">
                    <a href="manage_listings.php" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-primary"><?= $isEdit ? "Update Listing" : "Publish Internship Opening →" ?></button>
                </div>

            </form>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
