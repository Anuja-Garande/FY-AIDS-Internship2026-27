<?php
// company/dashboard.php - Company Recruiter Dashboard
require_once __DIR__ . '/../config/db_connect.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_role('Company');
$user = get_logged_in_user();
$pdo = getDB();

$companyId = $_SESSION['company_id'] ?? 0;

// Fetch company details
$stmtComp = $pdo->prepare("SELECT * FROM Companies WHERE Company_ID = ?");
$stmtComp->execute([$companyId]);
$company = $stmtComp->fetch();

// Count stats
$stmtListingsCount = $pdo->prepare("SELECT COUNT(*) FROM Internships WHERE Company_ID = ? AND Status = 'Open'");
$stmtListingsCount->execute([$companyId]);
$activeListings = $stmtListingsCount->fetchColumn();

$stmtAppsCount = $pdo->prepare("
    SELECT COUNT(*) 
    FROM Applications a
    JOIN Internships i ON a.Internship_ID = i.Internship_ID
    WHERE i.Company_ID = ?
");
$stmtAppsCount->execute([$companyId]);
$totalApps = $stmtAppsCount->fetchColumn();

$stmtShortlisted = $pdo->prepare("
    SELECT COUNT(*) 
    FROM Applications a
    JOIN Internships i ON a.Internship_ID = i.Internship_ID
    WHERE i.Company_ID = ? AND a.Status = 'Shortlisted'
");
$stmtShortlisted->execute([$companyId]);
$shortlistedApps = $stmtShortlisted->fetchColumn();

$stmtSelected = $pdo->prepare("
    SELECT COUNT(*) 
    FROM Applications a
    JOIN Internships i ON a.Internship_ID = i.Internship_ID
    WHERE i.Company_ID = ? AND a.Status = 'Selected'
");
$stmtSelected->execute([$companyId]);
$selectedApps = $stmtSelected->fetchColumn();

// Recent Applicants
$stmtRecentApps = $pdo->prepare("
    SELECT a.*, i.Title, u.Full_Name as Student_Name, s.Department, s.Resume_Path
    FROM Applications a
    JOIN Internships i ON a.Internship_ID = i.Internship_ID
    JOIN Students s ON a.Student_ID = s.Student_ID
    JOIN Users u ON s.User_ID = u.User_ID
    WHERE i.Company_ID = ?
    ORDER BY a.Applied_Date DESC
    LIMIT 5
");
$stmtRecentApps->execute([$companyId]);
$recentApplicants = $stmtRecentApps->fetchAll();

$page_title = "Recruiter Dashboard - " . sanitize($company['Company_Name'] ?? 'Company');
$active_page = "dashboard";
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
    <div>
        <h1 class="page-title">Welcome, <?= sanitize($company['Company_Name'] ?? $user['name']) ?> 🏢</h1>
        <p class="page-subtitle"><?= sanitize($company['Industry_Type'] ?? 'Industry Partner') ?> • Recruiter Portal</p>
    </div>
    <div style="display: flex; gap: 0.75rem;">
        <a href="post_internship.php" class="btn btn-primary">➕ Post New Internship</a>
        <a href="view_applicants.php" class="btn btn-outline">👥 View All Applicants</a>
    </div>
</div>

<!-- Metric Counters -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-content">
            <span class="stat-value"><?= $activeListings ?></span>
            <span class="stat-label">Active Listings</span>
        </div>
        <div class="stat-icon primary">📋</div>
    </div>

    <div class="stat-card">
        <div class="stat-content">
            <span class="stat-value"><?= $totalApps ?></span>
            <span class="stat-label">Total Applicants</span>
        </div>
        <div class="stat-icon info">👥</div>
    </div>

    <div class="stat-card">
        <div class="stat-content">
            <span class="stat-value"><?= $shortlistedApps ?></span>
            <span class="stat-label">Shortlisted Candidates</span>
        </div>
        <div class="stat-icon warning">⭐</div>
    </div>

    <div class="stat-card">
        <div class="stat-content">
            <span class="stat-value"><?= $selectedApps ?></span>
            <span class="stat-label">Hired / Selected</span>
        </div>
        <div class="stat-icon success">🎉</div>
    </div>
</div>

<!-- Recent Applicants Card -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Recent Student Applicants</h3>
        <a href="view_applicants.php" style="font-size: 0.85rem;">View All Candidates →</a>
    </div>
    <div class="card-body" style="padding: 0;">
        <?php if (empty($recentApplicants)): ?>
            <div class="empty-state" style="border: none;">
                <div class="empty-state-icon">📥</div>
                <div class="empty-state-title">No Applicants Yet</div>
                <p class="empty-state-desc">You haven't received any student applications for your posted listings yet.</p>
                <a href="post_internship.php" class="btn btn-sm btn-primary">Post a Role</a>
            </div>
        <?php else: ?>
            <div class="table-responsive" style="border: none;">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Candidate</th>
                            <th>Role Applied For</th>
                            <th>Applied Date</th>
                            <th>Resume</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recentApplicants as $applicant): ?>
                            <tr>
                                <td>
                                    <strong><?= sanitize($applicant['Student_Name']) ?></strong><br>
                                    <span style="font-size: 0.8rem; color: var(--text-muted);"><?= sanitize($applicant['Department']) ?></span>
                                </td>
                                <td>
                                    <strong><?= sanitize($applicant['Title']) ?></strong>
                                </td>
                                <td style="font-size: 0.85rem; color: var(--text-muted);">
                                    <?= date('M d, Y', strtotime($applicant['Applied_Date'])) ?>
                                </td>
                                <td>
                                    <?php if (!empty($applicant['Resume_Path'])): ?>
                                        <a href="<?= get_base_url() . sanitize($applicant['Resume_Path']) ?>" target="_blank" class="btn btn-sm btn-outline">📄 Resume PDF</a>
                                    <?php else: ?>
                                        <span style="font-size: 0.8rem; color: var(--danger-600);">No Resume</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?= render_status_badge($applicant['Status']) ?>
                                </td>
                                <td>
                                    <a href="view_applicants.php?listing_id=<?= $applicant['Internship_ID'] ?>" class="btn btn-sm btn-secondary">Review</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
