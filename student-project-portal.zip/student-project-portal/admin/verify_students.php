<?php
// admin/verify_students.php - Student Verification & Mentor Allocation
require_once __DIR__ . '/../config/db_connect.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_role('Admin');
$user = get_logged_in_user();
$pdo = getDB();

// Handle Mentor Assignment Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assign_mentor'])) {
    $studentId = (int)$_POST['student_id'];
    $mentorUserId = (int)$_POST['mentor_user_id'];

    try {
        $stmtAssign = $pdo->prepare("UPDATE Students SET Mentor_User_ID = ? WHERE Student_ID = ?");
        $stmtAssign->execute([$mentorUserId > 0 ? $mentorUserId : null, $studentId]);
        set_flash_message('success', 'Faculty mentor assignment updated successfully.');
    } catch (Exception $e) {
        set_flash_message('danger', 'Error updating mentor assignment: ' . $e->getMessage());
    }
    header('Location: verify_students.php');
    exit();
}

// Fetch all Faculty Mentors for dropdown options
$stmtFaculty = $pdo->query("SELECT User_ID, Full_Name, Email FROM Users WHERE Role = 'Faculty' ORDER BY Full_Name ASC");
$facultyMembers = $stmtFaculty->fetchAll();

// Fetch Students List
$stmtStudents = $pdo->query("
    SELECT s.Student_ID, s.Department, s.Current_Semester, s.Skills, s.Resume_Path, s.Mentor_User_ID,
           u.User_ID, u.Full_Name, u.Email, u.Registration_Date, u.Is_Verified,
           m.Full_Name as Mentor_Name
    FROM Students s
    JOIN Users u ON s.User_ID = u.User_ID
    LEFT JOIN Users m ON s.Mentor_User_ID = m.User_ID
    ORDER BY u.Registration_Date DESC
");
$students = $stmtStudents->fetchAll();

$page_title = "Student Verification & Mentor Allocation - Admin Portal";
$active_page = "verify";
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
    <div>
        <h1 class="page-title">Student Verification & Faculty Allocation</h1>
        <p class="page-subtitle">Verify self-registered student accounts and assign faculty academic mentors</p>
    </div>
</div>

<?php if (empty($students)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">🎓</div>
        <div class="empty-state-title">No Students Registered</div>
        <p class="empty-state-desc">There are no registered student accounts in the database.</p>
    </div>
<?php else: ?>
    <div class="table-responsive">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Student Name</th>
                    <th>Email & Dept</th>
                    <th>Semester</th>
                    <th>Assigned Faculty Mentor</th>
                    <th>Resume</th>
                    <th>Verification</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($students as $s): ?>
                    <tr>
                        <td>
                            <strong><?= sanitize($s['Full_Name']) ?></strong>
                        </td>
                        <td>
                            <span style="font-size: 0.85rem; display: block; color: var(--text-muted);"><?= sanitize($s['Email']) ?></span>
                            <span class="badge badge-info"><?= sanitize($s['Department']) ?></span>
                        </td>
                        <td style="font-size: 0.85rem;">
                            Sem <?= (int)$s['Current_Semester'] ?>
                        </td>
                        <td>
                            <?php if (!empty($s['Mentor_Name'])): ?>
                                <span style="font-size: 0.85rem; font-weight: 600; color: var(--accent-600);">👨‍🏫 <?= sanitize($s['Mentor_Name']) ?></span>
                            <?php else: ?>
                                <span class="badge badge-warning">Unassigned</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if (!empty($s['Resume_Path'])): ?>
                                <a href="<?= get_base_url() . sanitize($s['Resume_Path']) ?>" target="_blank" style="font-size: 0.8rem; font-weight: 600;">📄 View PDF</a>
                            <?php else: ?>
                                <span style="font-size: 0.8rem; color: var(--text-muted);">None</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="badge badge-success">Verified</span>
                        </td>
                        <td>
                            <!-- Form to Assign/Change Mentor -->
                            <form action="verify_students.php" method="POST" style="display: flex; gap: 0.5rem; align-items: center;">
                                <input type="hidden" name="assign_mentor" value="1">
                                <input type="hidden" name="student_id" value="<?= (int)$s['Student_ID'] ?>">
                                
                                <select name="mentor_user_id" class="form-select" style="width: auto; padding: 0.3rem 0.5rem; font-size: 0.8rem;">
                                    <option value="0">-- Assign Mentor --</option>
                                    <?php foreach ($facultyMembers as $f): ?>
                                        <option value="<?= $f['User_ID'] ?>" <?= $s['Mentor_User_ID'] == $f['User_ID'] ? 'selected' : '' ?>>
                                            <?= sanitize($f['Full_Name']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>

                                <button type="submit" class="btn btn-sm btn-outline">Save</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
