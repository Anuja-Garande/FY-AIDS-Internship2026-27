<?php
// admin/dashboard.php - System Administrator Dashboard
require_once __DIR__ . '/../config/db_connect.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_role('Admin');
$user = get_logged_in_user();
$pdo = getDB();

// Statistics
$totalStudents   = $pdo->query("SELECT COUNT(*) FROM Students")->fetchColumn();
$totalFaculty    = $pdo->query("SELECT COUNT(*) FROM Users WHERE Role = 'Faculty'")->fetchColumn();
$totalCompanies  = $pdo->query("SELECT COUNT(*) FROM Companies")->fetchColumn();
$totalOpenings   = $pdo->query("SELECT COUNT(*) FROM Internships WHERE Status = 'Open'")->fetchColumn();
$totalSelections = $pdo->query("SELECT COUNT(*) FROM Applications WHERE Status = 'Selected'")->fetchColumn();

// Recent Registrations
$stmtRecentStud = $pdo->query("
    SELECT u.Full_Name, u.Email, u.Registration_Date, s.Department, s.Current_Semester, m.Full_Name as Mentor_Name
    FROM Students s
    JOIN Users u ON s.User_ID = u.User_ID
    LEFT JOIN Users m ON s.Mentor_User_ID = m.User_ID
    ORDER BY u.Registration_Date DESC
    LIMIT 5
");
$recentStudents = $stmtRecentStud->fetchAll();

$page_title = "Admin Dashboard - SPPI Portal";
$active_page = "dashboard";
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
    <div>
        <h1 class="page-title">Administrator Portal 🛡️</h1>
        <p class="page-subtitle">College Master Data Management, Student Allocations & Analytics</p>
    </div>
    <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
        <a href="verify_students.php" class="btn btn-primary">🛡️ Student Allocations</a>
        <a href="reports.php" class="btn btn-outline">📈 Export Reports</a>
    </div>
</div>

<!-- Stats Grid -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-content">
            <span class="stat-value"><?= number_format($totalStudents) ?></span>
            <span class="stat-label">Registered Students</span>
        </div>
        <div class="stat-icon primary">🎓</div>
    </div>

    <div class="stat-card">
        <div class="stat-content">
            <span class="stat-value"><?= number_format($totalFaculty) ?></span>
            <span class="stat-label">Faculty Mentors</span>
        </div>
        <div class="stat-icon warning">👨‍🏫</div>
    </div>

    <div class="stat-card">
        <div class="stat-content">
            <span class="stat-value"><?= number_format($totalCompanies) ?></span>
            <span class="stat-label">Partner Companies</span>
        </div>
        <div class="stat-icon info">🏢</div>
    </div>

    <div class="stat-card">
        <div class="stat-content">
            <span class="stat-value"><?= number_format($totalOpenings) ?></span>
            <span class="stat-label">Active Internships</span>
        </div>
        <div class="stat-icon primary">💼</div>
    </div>

    <div class="stat-card">
        <div class="stat-content">
            <span class="stat-value"><?= number_format($totalSelections) ?></span>
            <span class="stat-label">Successful Hires</span>
        </div>
        <div class="stat-icon success">🎉</div>
    </div>
</div>

<!-- Admin Action Modules Grid -->
<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1.5rem; margin-bottom: 2rem;">
    
    <div class="card" style="padding: 1.25rem;">
        <div style="font-size: 1.8rem; margin-bottom: 0.5rem;">👨‍🎓</div>
        <h3 class="card-title" style="font-size: 1.1rem; margin-bottom: 0.25rem;">Student Mentor Allocation</h3>
        <p style="font-size: 0.85rem; color: var(--text-muted); margin-bottom: 1rem;">Assign faculty academic mentors to self-registered engineering students.</p>
        <a href="verify_students.php" class="btn btn-sm btn-primary">Manage Allocations →</a>
    </div>

    <div class="card" style="padding: 1.25rem;">
        <div style="font-size: 1.8rem; margin-bottom: 0.5rem;">🏢</div>
        <h3 class="card-title" style="font-size: 1.1rem; margin-bottom: 0.25rem;">Company Management</h3>
        <p style="font-size: 0.85rem; color: var(--text-muted); margin-bottom: 1rem;">Register new industry partners, recruiters, and manage company credentials.</p>
        <a href="manage_companies.php" class="btn btn-sm btn-primary">Manage Companies →</a>
    </div>

    <div class="card" style="padding: 1.25rem;">
        <div style="font-size: 1.8rem; margin-bottom: 0.5rem;">🏛️</div>
        <h3 class="card-title" style="font-size: 1.1rem; margin-bottom: 0.25rem;">Departments & Faculty</h3>
        <p style="font-size: 0.85rem; color: var(--text-muted); margin-bottom: 1rem;">Create faculty mentor accounts across engineering departments.</p>
        <a href="manage_departments.php" class="btn btn-sm btn-primary">Manage Faculty →</a>
    </div>

    <div class="card" style="padding: 1.25rem;">
        <div style="font-size: 1.8rem; margin-bottom: 0.5rem;">📊</div>
        <h3 class="card-title" style="font-size: 1.1rem; margin-bottom: 0.25rem;">Reports & Analytics</h3>
        <p style="font-size: 0.85rem; color: var(--text-muted); margin-bottom: 1rem;">View department placement rates, application funnels, and export summaries.</p>
        <a href="reports.php" class="btn btn-sm btn-primary">View Reports →</a>
    </div>

</div>

<!-- Recent Student Registrations -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Recent Student Registrations</h3>
        <a href="verify_students.php" style="font-size: 0.85rem;">View All Students →</a>
    </div>
    <div class="card-body" style="padding: 0;">
        <div class="table-responsive" style="border: none;">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Student Name</th>
                        <th>Email</th>
                        <th>Department</th>
                        <th>Semester</th>
                        <th>Assigned Mentor</th>
                        <th>Registration Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recentStudents as $s): ?>
                        <tr>
                            <td><strong><?= sanitize($s['Full_Name']) ?></strong></td>
                            <td style="font-size: 0.85rem; color: var(--text-muted);"><?= sanitize($s['Email']) ?></td>
                            <td style="font-size: 0.85rem;"><?= sanitize($s['Department']) ?></td>
                            <td style="font-size: 0.85rem;">Sem <?= (int)$s['Current_Semester'] ?></td>
                            <td>
                                <?php if (!empty($s['Mentor_Name'])): ?>
                                    <span class="badge badge-success"><?= sanitize($s['Mentor_Name']) ?></span>
                                <?php else: ?>
                                    <span class="badge badge-warning">Unassigned</span>
                                <?php endif; ?>
                            </td>
                            <td style="font-size: 0.85rem; color: var(--text-muted);"><?= date('M d, Y', strtotime($s['Registration_Date'])) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
