<?php
// admin/reports.php - System Reports & Analytics
require_once __DIR__ . '/../config/db_connect.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_role('Admin');
$user = get_logged_in_user();
$pdo = getDB();

// 1. Department-wise Summary
$stmtDept = $pdo->query("
    SELECT s.Department,
           COUNT(DISTINCT s.Student_ID) as Total_Students,
           COUNT(DISTINCT a.Application_ID) as Total_Applications,
           SUM(CASE WHEN a.Status IN ('Approved', 'Shortlisted', 'Selected') THEN 1 ELSE 0 END) as Faculty_Approved,
           SUM(CASE WHEN a.Status = 'Selected' THEN 1 ELSE 0 END) as Selected_Hired
    FROM Students s
    LEFT JOIN Applications a ON s.Student_ID = a.Student_ID
    GROUP BY s.Department
    ORDER BY Total_Students DESC
");
$deptSummary = $stmtDept->fetchAll();

// 2. Overall Status Breakdown
$stmtStatus = $pdo->query("
    SELECT Status, COUNT(*) as Count
    FROM Applications
    GROUP BY Status
    ORDER BY FIELD(Status, 'Submitted', 'Mentor Review', 'Approved', 'Shortlisted', 'Selected', 'Rejected')
");
$statusSummary = $stmtStatus->fetchAll();

// 3. Company Internship Postings Summary
$stmtCompSummary = $pdo->query("
    SELECT c.Company_Name, c.Industry_Type,
           COUNT(DISTINCT i.Internship_ID) as Postings_Count,
           COUNT(DISTINCT a.Application_ID) as Applicants_Count,
           SUM(CASE WHEN a.Status = 'Selected' THEN 1 ELSE 0 END) as Hired_Count
    FROM Companies c
    LEFT JOIN Internships i ON c.Company_ID = i.Company_ID
    LEFT JOIN Applications a ON i.Internship_ID = a.Internship_ID
    GROUP BY c.Company_ID
    ORDER BY Applicants_Count DESC
");
$companySummary = $stmtCompSummary->fetchAll();

$page_title = "Reports & Placement Analytics - Admin Portal";
$active_page = "reports";
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
    <div>
        <h1 class="page-title">Placement Reports & Analytical Summary</h1>
        <p class="page-subtitle">College-wide statistics, department performance metrics, and outcome distribution</p>
    </div>
    <div>
        <button onclick="window.print()" class="btn btn-primary">🖨️ Print / Save Report PDF</button>
    </div>
</div>

<!-- Application Funnel Outcome Breakdown Cards -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">1. Overall Application Outcome Funnel</h3>
    </div>
    <div class="card-body">
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 1rem;">
            <?php foreach ($statusSummary as $st): ?>
                <div style="background: var(--surface-alt); padding: 1rem; border-radius: var(--radius-sm); text-align: center; border: 1px solid var(--border-color);">
                    <div style="font-size: 1.6rem; font-weight: 700; color: var(--primary-900);"><?= (int)$st['Count'] ?></div>
                    <div style="margin-top: 0.25rem;"><?= render_status_badge($st['Status']) ?></div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- Department-wise Summary Table -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">2. Department-wise Internship Summary</h3>
    </div>
    <div class="card-body" style="padding: 0;">
        <div class="table-responsive" style="border: none;">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Department</th>
                        <th>Registered Students</th>
                        <th>Applications Submitted</th>
                        <th>Faculty Approved</th>
                        <th>Final Selections</th>
                        <th>Placement Rate</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($deptSummary as $d): ?>
                        <?php 
                        $rate = ($d['Total_Students'] > 0) ? round(($d['Selected_Hired'] / $d['Total_Students']) * 100, 1) : 0;
                        ?>
                        <tr>
                            <td><strong><?= sanitize($d['Department'] ?? 'Unassigned') ?></strong></td>
                            <td><?= (int)$d['Total_Students'] ?></td>
                            <td><?= (int)$d['Total_Applications'] ?></td>
                            <td><span class="badge badge-info"><?= (int)$d['Faculty_Approved'] ?></span></td>
                            <td><span class="badge badge-success"><?= (int)$d['Selected_Hired'] ?></span></td>
                            <td><strong><?= $rate ?>%</strong></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Company Internship Performance Summary Table -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">3. Partner Company Recruitment Overview</h3>
    </div>
    <div class="card-body" style="padding: 0;">
        <div class="table-responsive" style="border: none;">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Company Name</th>
                        <th>Industry Type</th>
                        <th>Total Openings Posted</th>
                        <th>Total Candidates Received</th>
                        <th>Candidates Hired</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($companySummary as $c): ?>
                        <tr>
                            <td><strong>🏢 <?= sanitize($c['Company_Name']) ?></strong></td>
                            <td><span class="badge badge-secondary"><?= sanitize($c['Industry_Type']) ?></span></td>
                            <td><?= (int)$c['Postings_Count'] ?></td>
                            <td><?= (int)$c['Applicants_Count'] ?></td>
                            <td><span class="badge badge-success">🎉 <?= (int)$c['Hired_Count'] ?></span></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
