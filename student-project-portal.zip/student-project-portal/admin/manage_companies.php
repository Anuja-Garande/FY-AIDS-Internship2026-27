<?php
// admin/manage_companies.php - Manage Partner Companies
require_once __DIR__ . '/../config/db_connect.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_role('Admin');
$user = get_logged_in_user();
$pdo = getDB();

$error = '';

// Handle creating a new company account
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_company'])) {
    $companyName   = trim($_POST['company_name'] ?? '');
    $industryType  = trim($_POST['industry_type'] ?? '');
    $contactNumber = trim($_POST['contact_number'] ?? '');
    $contactPerson = trim($_POST['contact_person'] ?? '');
    $email         = trim($_POST['email'] ?? '');
    $password      = $_POST['password'] ?? 'Password123';

    if (empty($companyName) || empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Company Name and valid Email are required.";
    } else {
        $stmtChk = $pdo->prepare("SELECT User_ID FROM Users WHERE Email = ?");
        $stmtChk->execute([$email]);
        if ($stmtChk->fetch()) {
            $error = "An account with this email address already exists.";
        } else {
            try {
                $pdo->beginTransaction();

                $hash = password_hash($password, PASSWORD_BCRYPT);
                $stmtUser = $pdo->prepare("
                    INSERT INTO Users (Full_Name, Email, Password_Hash, Role, Is_Verified)
                    VALUES (?, ?, ?, 'Company', 1)
                ");
                $stmtUser->execute([$contactPerson ?: $companyName, $email, $hash]);
                $userId = $pdo->lastInsertId();

                $stmtComp = $pdo->prepare("
                    INSERT INTO Companies (User_ID, Company_Name, Industry_Type, Contact_Number)
                    VALUES (?, ?, ?, ?)
                ");
                $stmtComp->execute([$userId, $companyName, $industryType, $contactNumber]);

                $pdo->commit();

                set_flash_message('success', "Partner Company '$companyName' created successfully!");
                header('Location: manage_companies.php');
                exit();
            } catch (Exception $e) {
                $pdo->rollBack();
                $error = "Database error: " . $e->getMessage();
            }
        }
    }
}

// Fetch list of companies with active job counts
$stmtCompanies = $pdo->query("
    SELECT c.*, u.Full_Name as Recruiter_Name, u.Email, u.Registration_Date,
           (SELECT COUNT(*) FROM Internships WHERE Company_ID = c.Company_ID) as Total_Listings
    FROM Companies c
    JOIN Users u ON c.User_ID = u.User_ID
    ORDER BY c.Company_Name ASC
");
$companies = $stmtCompanies->fetchAll();

$page_title = "Manage Companies - Admin Portal";
$active_page = "companies";
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
    <div>
        <h1 class="page-title">Manage Industry Partner Companies</h1>
        <p class="page-subtitle">Register and oversee partner organizations posting internships on SPPI</p>
    </div>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger"><?= sanitize($error) ?></div>
<?php endif; ?>

<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 1.5rem;">
    
    <!-- Companies List -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Registered Partner Companies</h3>
        </div>
        <div class="card-body" style="padding: 0;">
            <div class="table-responsive" style="border: none;">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Company Name</th>
                            <th>Industry & Contact</th>
                            <th>Recruiter Email</th>
                            <th>Listings</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($companies as $comp): ?>
                            <tr>
                                <td>
                                    <strong>🏢 <?= sanitize($comp['Company_Name']) ?></strong><br>
                                    <span style="font-size: 0.8rem; color: var(--text-muted);"><?= sanitize($comp['Recruiter_Name']) ?></span>
                                </td>
                                <td>
                                    <span class="badge badge-info"><?= sanitize($comp['Industry_Type']) ?></span><br>
                                    <span style="font-size: 0.8rem; color: var(--text-muted);"><?= sanitize($comp['Contact_Number']) ?></span>
                                </td>
                                <td style="font-size: 0.85rem; color: var(--text-muted);">
                                    <?= sanitize($comp['Email']) ?>
                                </td>
                                <td>
                                    <span class="badge badge-primary"><?= (int)$comp['Total_Listings'] ?> Job(s)</span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Create Company Account Form -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Register New Company Partner</h3>
        </div>
        <div class="card-body">
            <form action="manage_companies.php" method="POST" data-validate>
                <input type="hidden" name="create_company" value="1">

                <div class="form-group">
                    <label class="form-label" for="company_name">Company Name *</label>
                    <input type="text" id="company_name" name="company_name" class="form-control" placeholder="e.g. Acme Tech Corp" required>
                </div>

                <div class="form-group">
                    <label class="form-label" for="industry_type">Industry Sector *</label>
                    <input type="text" id="industry_type" name="industry_type" class="form-control" placeholder="e.g. Software & Cloud Solutions" required>
                </div>

                <div class="form-group">
                    <label class="form-label" for="contact_person">Recruiter / HR Contact Person</label>
                    <input type="text" id="contact_person" name="contact_person" class="form-control" placeholder="e.g. Sarah Jenkins (HR)">
                </div>

                <div class="form-group">
                    <label class="form-label" for="email">Recruiter Login Email *</label>
                    <input type="email" id="email" name="email" class="form-control" placeholder="recruitment@acmetech.com" required>
                </div>

                <div class="form-group">
                    <label class="form-label" for="contact_number">Contact Phone Number</label>
                    <input type="text" id="contact_number" name="contact_number" class="form-control" placeholder="+1 (555) 019-2834">
                </div>

                <div class="form-group">
                    <label class="form-label" for="password">Password *</label>
                    <input type="password" id="password" name="password" class="form-control" value="Password123" required>
                    <span class="form-text">Default password set to: <code>Password123</code></span>
                </div>

                <button type="submit" class="btn btn-primary btn-block" style="margin-top: 1.25rem;">+ Register Company Partner</button>
            </form>
        </div>
    </div>

</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
