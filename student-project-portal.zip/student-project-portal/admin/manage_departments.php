<?php
// admin/manage_departments.php - Manage Faculty Members & Departments
require_once __DIR__ . '/../config/db_connect.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_role('Admin');
$user = get_logged_in_user();
$pdo = getDB();

$error = '';

// Form handler for adding a new Faculty Mentor account
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_faculty'])) {
    $name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? 'Password123';

    if (empty($name) || empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Valid Full Name and Email address are required.";
    } else {
        // Check duplicate
        $stmtChk = $pdo->prepare("SELECT User_ID FROM Users WHERE Email = ?");
        $stmtChk->execute([$email]);
        if ($stmtChk->fetch()) {
            $error = "An account with this email address already exists.";
        } else {
            try {
                $hash = password_hash($password, PASSWORD_BCRYPT);
                $stmtIns = $pdo->prepare("
                    INSERT INTO Users (Full_Name, Email, Password_Hash, Role, Is_Verified)
                    VALUES (?, ?, ?, 'Faculty', 1)
                ");
                $stmtIns->execute([$name, $email, $hash]);

                set_flash_message('success', "Faculty Mentor '$name' created successfully!");
                header('Location: manage_departments.php');
                exit();
            } catch (Exception $e) {
                $error = "Database error: " . $e->getMessage();
            }
        }
    }
}

// Fetch Faculty List with count of assigned mentees
$stmtFacultyList = $pdo->query("
    SELECT u.User_ID, u.Full_Name, u.Email, u.Registration_Date,
           (SELECT COUNT(*) FROM Students WHERE Mentor_User_ID = u.User_ID) as Mentee_Count
    FROM Users u
    WHERE u.Role = 'Faculty'
    ORDER BY u.Full_Name ASC
");
$facultyMembers = $stmtFacultyList->fetchAll();

$page_title = "Faculty & Departments - Admin Portal";
$active_page = "departments";
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
    <div>
        <h1 class="page-title">Manage Faculty Mentors & Departments</h1>
        <p class="page-subtitle">Add and view academic faculty mentors across engineering departments</p>
    </div>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger"><?= sanitize($error) ?></div>
<?php endif; ?>

<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 1.5rem;">
    
    <!-- Faculty List Table -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Existing Faculty Mentors</h3>
        </div>
        <div class="card-body" style="padding: 0;">
            <div class="table-responsive" style="border: none;">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Faculty Name</th>
                            <th>Email</th>
                            <th>Assigned Mentees</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($facultyMembers as $f): ?>
                            <tr>
                                <td>
                                    <strong>Dr./Prof. <?= sanitize($f['Full_Name']) ?></strong>
                                </td>
                                <td style="font-size: 0.85rem; color: var(--text-muted);">
                                    <?= sanitize($f['Email']) ?>
                                </td>
                                <td>
                                    <span class="badge badge-info">🎓 <?= (int)$f['Mentee_Count'] ?> Student(s)</span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Create Faculty Form -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Create Faculty Mentor Account</h3>
        </div>
        <div class="card-body">
            <form action="manage_departments.php" method="POST" data-validate>
                <input type="hidden" name="create_faculty" value="1">

                <div class="form-group">
                    <label class="form-label" for="full_name">Full Name *</label>
                    <input type="text" id="full_name" name="full_name" class="form-control" placeholder="e.g. Dr. Sarah Jenkins" required>
                </div>

                <div class="form-group">
                    <label class="form-label" for="email">College Email Address *</label>
                    <input type="email" id="email" name="email" class="form-control" placeholder="sjenkins@sppi.edu" required>
                </div>

                <div class="form-group">
                    <label class="form-label" for="password">Password *</label>
                    <input type="password" id="password" name="password" class="form-control" value="Password123" required>
                    <span class="form-text">Default password set to: <code>Password123</code></span>
                </div>

                <button type="submit" class="btn btn-primary btn-block" style="margin-top: 1.25rem;">+ Create Faculty Account</button>
            </form>
        </div>
    </div>

</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
