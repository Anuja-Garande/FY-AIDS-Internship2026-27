<?php
// config/db_connect.php
// Database connection configuration for Student Project Portal for Internship (SPPI)

$host = 'localhost';
$db   = 'sppi_db';
$user = 'root';
$pass = ''; // Default XAMPP MySQL password is empty
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    // If database doesn't exist yet or connection fails, render a clear helper message
    die("<div style='font-family: sans-serif; padding: 2rem; background: #fee2e2; color: #991b1b; border-radius: 8px; margin: 2rem auto; max-width: 600px;'>
            <h2 style='margin-top:0;'>Database Connection Error</h2>
            <p>Could not connect to MySQL database <strong>{$db}</strong> on <strong>{$host}</strong>.</p>
            <p><strong>Error:</strong> " . htmlspecialchars($e->getMessage()) . "</p>
            <hr style='border-color: #fca5a5;'>
            <p><strong>Setup Instructions:</strong></p>
            <ol>
                <li>Make sure XAMPP / MySQL service is running.</li>
                <li>Import the SQL file located at: <code>database/sppi_schema.sql</code> in phpMyAdmin.</li>
            </ol>
        </div>");
}

/**
 * Returns active PDO connection instance
 */
function getDB() {
    global $pdo;
    return $pdo;
}
?>
