<?php
// index.php - Main Landing Page
require_once __DIR__ . '/config/db_connect.php';
require_once __DIR__ . '/includes/auth_check.php';

$pdo = getDB();

// Fetch summary metrics for landing page
$statListings = 0;
$statCompanies = 0;
$statStudents = 0;
$statApplications = 0;

$dbConfigured = true;
try {
    $statListings = $pdo->query("SELECT COUNT(*) FROM Internships WHERE Status = 'Open'")->fetchColumn();
    $statCompanies = $pdo->query("SELECT COUNT(*) FROM Companies")->fetchColumn();
    $statStudents = $pdo->query("SELECT COUNT(*) FROM Students")->fetchColumn();
    $statApplications = $pdo->query("SELECT COUNT(*) FROM Applications WHERE Status = 'Selected'")->fetchColumn();
} catch (Exception $e) {
    $dbConfigured = false;
}

$page_title = "Welcome - Student Project Portal for Internship (SPPI)";
require_once __DIR__ . '/includes/header.php';
?>

<?php if (!$dbConfigured): ?>
    <div style="max-width: 1200px; margin: 1.5rem auto 0 auto; padding: 0 1.5rem;">
        <div class="alert alert-warning">
            <div>
                <strong>⚠️ Database Schema Setup Needed:</strong> Database tables have not been imported into phpMyAdmin yet. 
                Please import the SQL file located at <code>database/sppi_schema.sql</code> into your MySQL database <code>sppi_db</code>.
            </div>
        </div>
    </div>
<?php endif; ?>

<!-- Hero Banner Section -->
<section style="background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); color: #ffffff; padding: 4rem 1.5rem; text-align: center; border-bottom: 4px solid var(--accent-600);">
    <div style="max-width: 900px; margin: 0 auto;">
        <span class="badge badge-primary" style="margin-bottom: 1rem; font-size: 0.85rem; padding: 0.4rem 1rem;">Engineering College Placement & Internship Cell</span>
        <h1 style="font-size: 2.75rem; font-weight: 800; letter-spacing: -0.03em; margin-bottom: 1rem; line-height: 1.2;">
            Student Project Portal for Internship
        </h1>
        <p style="font-size: 1.15rem; color: #94a3b8; margin-bottom: 2rem; max-width: 750px; margin-left: auto; margin-right: auto;">
            A unified, transparent internship platform connecting engineering students, faculty academic mentors, industry partner companies, and placement administrators.
        </p>

        <div style="display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap;">
            <?php if (is_logged_in()): ?>
                <a href="<?= get_dashboard_url_for_role($_SESSION['user_role'] ?? '') ?>" class="btn btn-primary" style="padding: 0.8rem 1.75rem; font-size: 1rem;">
                    Go to Your Dashboard →
                </a>
            <?php else: ?>
                <a href="auth/register.php" class="btn btn-primary" style="padding: 0.8rem 1.75rem; font-size: 1rem;">
                    🚀 Student Self-Register
                </a>
                <a href="auth/login.php" class="btn btn-outline" style="padding: 0.8rem 1.75rem; font-size: 1rem; color: #ffffff; border-color: #475569;">
                    🔑 Portal Login
                </a>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Live Stats Counter Grid -->
<section style="max-width: 1200px; margin: -2rem auto 3rem auto; padding: 0 1.5rem; position: relative; z-index: 10;">
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-content">
                <span class="stat-value"><?= number_format($statListings) ?></span>
                <span class="stat-label">Active Internships</span>
            </div>
            <div class="stat-icon primary">💼</div>
        </div>

        <div class="stat-card">
            <div class="stat-content">
                <span class="stat-value"><?= number_format($statCompanies) ?></span>
                <span class="stat-label">Partner Companies</span>
            </div>
            <div class="stat-icon info">🏢</div>
        </div>

        <div class="stat-card">
            <div class="stat-content">
                <span class="stat-value"><?= number_format($statStudents) ?></span>
                <span class="stat-label">Registered Students</span>
            </div>
            <div class="stat-icon success">🎓</div>
        </div>

        <div class="stat-card">
            <div class="stat-content">
                <span class="stat-value"><?= number_format($statApplications) ?></span>
                <span class="stat-label">Successful Selections</span>
            </div>
            <div class="stat-icon warning">🎉</div>
        </div>
    </div>
</section>

<!-- Features Overview Grid -->
<section style="max-width: 1200px; margin: 0 auto 4rem auto; padding: 0 1.5rem;">
    <div style="text-align: center; margin-bottom: 3rem;">
        <h2 style="font-size: 1.8rem; font-weight: 700; color: var(--primary-900);">Built for Every Stakeholder</h2>
        <p style="color: var(--text-muted); font-size: 0.95rem;">Streamlined workflow from application to final selection</p>
    </div>

    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 1.5rem;">
        
        <!-- Role Card: Student -->
        <div class="card" style="padding: 1.5rem;">
            <div style="font-size: 2rem; margin-bottom: 0.75rem;">👨‍🎓</div>
            <h3 style="font-size: 1.2rem; font-weight: 600; margin-bottom: 0.5rem; color: var(--primary-900);">For Students</h3>
            <p style="font-size: 0.875rem; color: var(--text-muted); line-height: 1.5;">
                Self-register, build your engineering skills profile, upload PDF resume, explore company listings, and track real-time mentor approval status.
            </p>
        </div>

        <!-- Role Card: Faculty Mentor -->
        <div class="card" style="padding: 1.5rem;">
            <div style="font-size: 2rem; margin-bottom: 0.75rem;">👩‍🏫</div>
            <h3 style="font-size: 1.2rem; font-weight: 600; margin-bottom: 0.5rem; color: var(--primary-900);">For Faculty Mentors</h3>
            <p style="font-size: 0.875rem; color: var(--text-muted); line-height: 1.5;">
                Review student application queues, verify student qualifications & resumes, provide written feedback, and approve candidates for company selection.
            </p>
        </div>

        <!-- Role Card: Company -->
        <div class="card" style="padding: 1.5rem;">
            <div style="font-size: 2rem; margin-bottom: 0.75rem;">🏢</div>
            <h3 style="font-size: 1.2rem; font-weight: 600; margin-bottom: 0.5rem; color: var(--primary-900);">For Companies</h3>
            <p style="font-size: 0.875rem; color: var(--text-muted); line-height: 1.5;">
                Post internship openings, specify skill requirements, view faculty-verified student candidates, download resumes, and mark status to Shortlisted/Selected.
            </p>
        </div>

        <!-- Role Card: Admin -->
        <div class="card" style="padding: 1.5rem;">
            <div style="font-size: 2rem; margin-bottom: 0.75rem;">🛡️</div>
            <h3 style="font-size: 1.2rem; font-weight: 600; margin-bottom: 0.5rem; color: var(--primary-900);">For Administrators</h3>
            <p style="font-size: 0.875rem; color: var(--text-muted); line-height: 1.5;">
                Manage master academic departments, faculty mentor allocations, company profiles, student verification queues, and export analytical reports.
            </p>
        </div>

    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
