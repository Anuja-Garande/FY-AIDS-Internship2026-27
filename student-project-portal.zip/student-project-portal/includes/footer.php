<?php
// includes/footer.php
require_once __DIR__ . '/auth_check.php';
$base_url = get_base_url();
$user = get_logged_in_user();
?>

    </main>

    <?php if ($user): ?>
        </div> <!-- end .main-wrapper -->
    </div> <!-- end .app-container -->
    <?php endif; ?>

    <footer style="background-color: var(--surface-white); border-top: 1px solid var(--border-color); padding: 1.5rem 2rem; text-align: center; font-size: 0.85rem; color: var(--text-muted); margin-top: auto;">
        <div style="max-width: 1400px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem;">
            <div>
                &copy; <?= date('Y') ?> <strong>Student Project Portal for Internship (SPPI)</strong>. All rights reserved.
            </div>
            <div style="display: flex; gap: 1.5rem;">
                <a href="<?= $base_url ?>index.php" style="color: var(--text-muted);">Home</a>
                <a href="#" style="color: var(--text-muted);">Privacy Policy</a>
                <a href="#" style="color: var(--text-muted);">Helpdesk</a>
            </div>
        </div>
    </footer>

    <!-- Core Scripts -->
    <script src="<?= $base_url ?>assets/js/validation.js"></script>
    <script src="<?= $base_url ?>assets/js/main.js"></script>
</body>
</html>
