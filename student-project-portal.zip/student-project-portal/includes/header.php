<?php
// includes/header.php
require_once __DIR__ . '/auth_check.php';

$user = get_logged_in_user();
$base_url = get_base_url();
$page_title = $page_title ?? 'SPPI - Student Project Portal for Internship';
$active_page = $active_page ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= sanitize($page_title) ?></title>
    
    <!-- CSS Stylesheets -->
    <link rel="stylesheet" href="<?= $base_url ?>assets/css/style.css">
    <link rel="stylesheet" href="<?= $base_url ?>assets/css/components.css">
    <link rel="stylesheet" href="<?= $base_url ?>assets/css/dashboard.css">
</head>
<body>

<?php if ($user): ?>
<!-- Protected Layout Shell with Sidebar & Top Navbar -->
<div class="app-container">
    <!-- Sidebar Navigation -->
    <aside class="sidebar" id="appSidebar">
        <div class="sidebar-header">
            <a href="<?= $base_url ?>index.php" class="brand-logo" style="color: #fff;">
                <span>🎓 SPPI Portal</span>
            </a>
        </div>
        
        <ul class="sidebar-menu">
            <li class="sidebar-label">Navigation</li>

            <?php if (strcasecmp($user['role'], 'Student') === 0): ?>
                <li class="sidebar-item">
                    <a href="<?= $base_url ?>student/dashboard.php" class="sidebar-link <?= $active_page === 'dashboard' ? 'active' : '' ?>">
                        <span class="sidebar-icon">📊</span> Dashboard
                    </a>
                </li>
                <li class="sidebar-item">
                    <a href="<?= $base_url ?>student/browse_internships.php" class="sidebar-link <?= $active_page === 'browse' ? 'active' : '' ?>">
                        <span class="sidebar-icon">🔍</span> Browse Internships
                    </a>
                </li>
                <li class="sidebar-item">
                    <a href="<?= $base_url ?>student/my_applications.php" class="sidebar-link <?= $active_page === 'applications' ? 'active' : '' ?>">
                        <span class="sidebar-icon">📝</span> My Applications
                    </a>
                </li>
                <li class="sidebar-item">
                    <a href="<?= $base_url ?>student/profile.php" class="sidebar-link <?= $active_page === 'profile' ? 'active' : '' ?>">
                        <span class="sidebar-icon">👤</span> Profile & Resume
                    </a>
                </li>

            <?php elseif (strcasecmp($user['role'], 'Faculty') === 0): ?>
                <li class="sidebar-item">
                    <a href="<?= $base_url ?>faculty/dashboard.php" class="sidebar-link <?= $active_page === 'dashboard' ? 'active' : '' ?>">
                        <span class="sidebar-icon">📊</span> Dashboard
                    </a>
                </li>
                <li class="sidebar-item">
                    <a href="<?= $base_url ?>faculty/review_applications.php" class="sidebar-link <?= $active_page === 'review' ? 'active' : '' ?>">
                        <span class="sidebar-icon">✅</span> Review Queue
                    </a>
                </li>

            <?php elseif (strcasecmp($user['role'], 'Company') === 0): ?>
                <li class="sidebar-item">
                    <a href="<?= $base_url ?>company/dashboard.php" class="sidebar-link <?= $active_page === 'dashboard' ? 'active' : '' ?>">
                        <span class="sidebar-icon">📊</span> Dashboard
                    </a>
                </li>
                <li class="sidebar-item">
                    <a href="<?= $base_url ?>company/post_internship.php" class="sidebar-link <?= $active_page === 'post' ? 'active' : '' ?>">
                        <span class="sidebar-icon">➕</span> Post Internship
                    </a>
                </li>
                <li class="sidebar-item">
                    <a href="<?= $base_url ?>company/manage_listings.php" class="sidebar-link <?= $active_page === 'listings' ? 'active' : '' ?>">
                        <span class="sidebar-icon">📋</span> Manage Listings
                    </a>
                </li>
                <li class="sidebar-item">
                    <a href="<?= $base_url ?>company/view_applicants.php" class="sidebar-link <?= $active_page === 'applicants' ? 'active' : '' ?>">
                        <span class="sidebar-icon">👥</span> View Applicants
                    </a>
                </li>

            <?php elseif (strcasecmp($user['role'], 'Admin') === 0): ?>
                <li class="sidebar-item">
                    <a href="<?= $base_url ?>admin/dashboard.php" class="sidebar-link <?= $active_page === 'dashboard' ? 'active' : '' ?>">
                        <span class="sidebar-icon">📊</span> Admin Dashboard
                    </a>
                </li>
                <li class="sidebar-item">
                    <a href="<?= $base_url ?>admin/verify_students.php" class="sidebar-link <?= $active_page === 'verify' ? 'active' : '' ?>">
                        <span class="sidebar-icon">🛡️</span> Student Verification
                    </a>
                </li>
                <li class="sidebar-item">
                    <a href="<?= $base_url ?>admin/manage_companies.php" class="sidebar-link <?= $active_page === 'companies' ? 'active' : '' ?>">
                        <span class="sidebar-icon">🏢</span> Manage Companies
                    </a>
                </li>
                <li class="sidebar-item">
                    <a href="<?= $base_url ?>admin/manage_departments.php" class="sidebar-link <?= $active_page === 'departments' ? 'active' : '' ?>">
                        <span class="sidebar-icon">🏛️</span> Departments & Faculty
                    </a>
                </li>
                <li class="sidebar-item">
                    <a href="<?= $base_url ?>admin/reports.php" class="sidebar-link <?= $active_page === 'reports' ? 'active' : '' ?>">
                        <span class="sidebar-icon">📈</span> Reports & Analytics
                    </a>
                </li>
            <?php endif; ?>
        </ul>

        <div class="sidebar-footer">
            <a href="<?= $base_url ?>auth/logout.php" class="sidebar-link" style="color: #f87171;">
                <span class="sidebar-icon">🚪</span> Log Out
            </a>
        </div>
    </aside>

    <!-- Content Area & Top Navbar -->
    <div class="main-wrapper">
        <header class="top-navbar">
            <div class="nav-left">
                <button type="button" class="mobile-toggle" id="mobileSidebarToggle">☰</button>
                <span style="font-weight: 600; color: var(--primary-900);">Student Project Portal for Internship</span>
            </div>
            
            <div class="user-profile-menu">
                <div class="user-details" style="text-align: right;">
                    <span class="user-name"><?= sanitize($user['name']) ?></span>
                    <span class="user-role"><?= sanitize($user['role']) ?></span>
                </div>
                <div class="user-avatar">
                    <?= strtoupper(substr($user['name'], 0, 1)) ?>
                </div>
            </div>
        </header>

        <main class="content-area">
            <?php 
            $flash = get_flash_message();
            if ($flash): 
            ?>
                <div class="alert alert-<?= sanitize($flash['type']) ?> alert-dismissible">
                    <span><?= sanitize($flash['text']) ?></span>
                </div>
            <?php endif; ?>
<?php else: ?>
<!-- Public Header (Landing Page / Auth) -->
<nav class="top-navbar">
    <div class="nav-left">
        <a href="<?= $base_url ?>index.php" class="brand-logo">
            🎓 <span>SPPI Portal</span>
        </a>
    </div>
    <div>
        <a href="<?= $base_url ?>auth/login.php" class="btn btn-outline btn-sm">Login</a>
        <a href="<?= $base_url ?>auth/register.php" class="btn btn-primary btn-sm" style="margin-left: 0.5rem;">Register Student</a>
    </div>
</nav>

<main style="min-height: calc(100vh - 140px);">
    <?php 
    $flash = get_flash_message();
    if ($flash): 
    ?>
        <div style="max-width: 1200px; margin: 1.5rem auto 0 auto; padding: 0 1.5rem;">
            <div class="alert alert-<?= sanitize($flash['type']) ?> alert-dismissible">
                <span><?= sanitize($flash['text']) ?></span>
            </div>
        </div>
    <?php endif; ?>
<?php endif; ?>
