<?php
// includes/auth_check.php
// Auth Guard & Session Utilities for SPPI

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Check if a user is logged in
 */
function is_logged_in() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Get current logged in user metadata array
 */
function get_logged_in_user() {
    if (!is_logged_in()) {
        return null;
    }
    $rawRole = $_SESSION['user_role'] ?? '';
    // Normalize role string (e.g. 'admin' -> 'Admin')
    $role = ucfirst(strtolower(trim($rawRole)));
    
    return [
        'id'        => $_SESSION['user_id'],
        'name'      => $_SESSION['user_name'] ?? 'User',
        'email'     => $_SESSION['user_email'] ?? '',
        'role'      => $role,
        'raw_role'  => $rawRole,
        'student_id'=> $_SESSION['student_id'] ?? null,
        'company_id'=> $_SESSION['company_id'] ?? null
    ];
}

/**
 * Get dashboard URL for a given role
 */
function get_dashboard_url_for_role($role) {
    $role = strtolower(trim($role ?? ''));
    $baseUrl = get_base_url();

    if ($role === 'admin') return $baseUrl . 'admin/dashboard.php';
    if ($role === 'faculty') return $baseUrl . 'faculty/dashboard.php';
    if ($role === 'company') return $baseUrl . 'company/dashboard.php';
    return $baseUrl . 'student/dashboard.php';
}

/**
 * Require login guard. Redirects to login page if unauthenticated.
 */
function require_login() {
    if (!is_logged_in()) {
        set_flash_message('danger', 'Please log in to access this page.');
        header('Location: ' . get_base_url() . 'auth/login.php');
        exit();
    }
}

/**
 * Require specific role guard (can pass string or array of strings)
 */
function require_role($roles) {
    require_login();
    if (is_string($roles)) {
        $roles = [$roles];
    }
    
    $current_role = strtolower(trim($_SESSION['user_role'] ?? ''));
    $allowed_roles = array_map(function($r) { return strtolower(trim($r)); }, $roles);

    if (!in_array($current_role, $allowed_roles)) {
        set_flash_message('danger', 'Unauthorized access: You do not have permission for this section.');
        header('Location: ' . get_base_url() . 'index.php');
        exit();
    }
}

/**
 * Determine dynamic base URL for absolute paths in links/redirects
 */
function get_base_url() {
    // Detect script path relative to root
    $script = $_SERVER['SCRIPT_NAME'] ?? '';
    if (strpos($script, '/auth/') !== false) return '../';
    if (strpos($script, '/admin/') !== false) return '../';
    if (strpos($script, '/faculty/') !== false) return '../';
    if (strpos($script, '/student/') !== false) return '../';
    if (strpos($script, '/company/') !== false) return '../';
    return './';
}

/**
 * Set flash message in session
 */
function set_flash_message($type, $message) {
    $_SESSION['flash_message'] = [
        'type' => $type, // success, danger, warning, info
        'text' => $message
    ];
}

/**
 * Get and clear flash message
 */
function get_flash_message() {
    if (isset($_SESSION['flash_message'])) {
        $flash = $_SESSION['flash_message'];
        unset($_SESSION['flash_message']);
        return $flash;
    }
    return null;
}

/**
 * Sanitize string output
 */
function sanitize($str) {
    return htmlspecialchars(trim($str ?? ''), ENT_QUOTES, 'UTF-8');
}

/**
 * Render HTML status pill badge
 */
function render_status_badge($status) {
    $status = trim($status ?? '');
    $badgeClass = 'badge-secondary';
    
    switch ($status) {
        case 'Submitted':
            $badgeClass = 'badge-info';
            break;
        case 'Mentor Review':
            $badgeClass = 'badge-warning';
            break;
        case 'Approved':
            $badgeClass = 'badge-primary';
            break;
        case 'Shortlisted':
            $badgeClass = 'badge-accent';
            break;
        case 'Selected':
            $badgeClass = 'badge-success';
            break;
        case 'Rejected':
            $badgeClass = 'badge-danger';
            break;
        case 'Open':
            $badgeClass = 'badge-success';
            break;
        case 'Closed':
            $badgeClass = 'badge-secondary';
            break;
    }
    
    return '<span class="badge ' . $badgeClass . '">' . sanitize($status) . '</span>';
}
?>
