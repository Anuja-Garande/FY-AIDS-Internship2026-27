/**
 * SPPI - Client-side Form Validation Library
 */

document.addEventListener('DOMContentLoaded', () => {
  const forms = document.querySelectorAll('form[data-validate]');

  forms.forEach(form => {
    form.addEventListener('submit', (e) => {
      let isValid = true;
      const inputs = form.querySelectorAll('[required], [data-match], [data-min-length]');

      inputs.forEach(input => {
        // Clear previous error states
        clearError(input);

        // Required check
        if (input.hasAttribute('required') && !input.value.trim()) {
          showError(input, 'This field is required.');
          isValid = false;
          return;
        }

        // Email format check
        if (input.type === 'email' && input.value.trim()) {
          const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
          if (!emailRegex.test(input.value.trim())) {
            showError(input, 'Please enter a valid email address.');
            isValid = false;
            return;
          }
        }

        // Minimum length check
        if (input.hasAttribute('data-min-length')) {
          const minLen = parseInt(input.getAttribute('data-min-length'), 10);
          if (input.value.length < minLen) {
            showError(input, `Must be at least ${minLen} characters long.`);
            isValid = false;
            return;
          }
        }

        // Password matching check
        if (input.hasAttribute('data-match')) {
          const targetId = input.getAttribute('data-match');
          const targetInput = document.getElementById(targetId);
          if (targetInput && input.value !== targetInput.value) {
            showError(input, 'Passwords do not match.');
            isValid = false;
            return;
          }
        }
      });

      if (!isValid) {
        e.preventDefault();
      }
    });
  });

  function showError(input, message) {
    input.classList.add('is-invalid');
    let parent = input.closest('.form-group') || input.parentElement;
    let errorElem = parent.querySelector('.invalid-feedback');
    
    if (!errorElem) {
      errorElem = document.createElement('div');
      errorElem.className = 'invalid-feedback';
      parent.appendChild(errorElem);
    }
    errorElem.textContent = message;
  }

  function clearError(input) {
    input.classList.remove('is-invalid');
    let parent = input.closest('.form-group') || input.parentElement;
    let errorElem = parent.querySelector('.invalid-feedback');
    if (errorElem) {
      errorElem.textContent = '';
    }
  }
});
