<?php
// auth/register.php - Student Self-Registration
require_once __DIR__ . '/../config/db_connect.php';
require_once __DIR__ . '/../includes/auth_check.php';

// Redirect if already logged in
if (is_logged_in()) {
    header('Location: ../index.php');
    exit();
}

$errors = [];
$name = '';
$email = '';
$department = '';
$semester = 1;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $department = trim($_POST['department'] ?? '');
    $semester = (int)($_POST['semester'] ?? 1);

    // Validation
    if (empty($name)) $errors[] = "Full name is required.";
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "A valid email address is required.";
    if (strlen($password) < 6) $errors[] = "Password must be at least 6 characters long.";
    if ($password !== $confirm_password) $errors[] = "Password confirmation does not match.";
    if (empty($department)) $errors[] = "Please select your department.";

    // Check duplicate email
    if (empty($errors)) {
        $pdo = getDB();
        $stmt = $pdo->prepare("SELECT User_ID FROM Users WHERE Email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $errors[] = "An account with this email address already exists.";
        }
    }

    // Process Registration
    if (empty($errors)) {
        try {
            $pdo->beginTransaction();

            $hash = password_hash($password, PASSWORD_BCRYPT);
            $stmtUser = $pdo->prepare("INSERT INTO Users (Full_Name, Email, Password_Hash, Role, Is_Verified) VALUES (?, ?, ?, 'Student', 1)");
            $stmtUser->execute([$name, $email, $hash]);
            $userId = $pdo->lastInsertId();

            $stmtStudent = $pdo->prepare("INSERT INTO Students (User_ID, Department, Current_Semester) VALUES (?, ?, ?)");
            $stmtStudent->execute([$userId, $department, $semester]);

            $pdo->commit();

            set_flash_message('success', 'Registration successful! You can now log in to your account.');
            header('Location: login.php');
            exit();

        } catch (Exception $e) {
            $pdo->rollBack();
            $errors[] = "Registration failed due to a database error. Please try again.";
        }
    }
}

$page_title = "Student Registration - SPPI Portal";
require_once __DIR__ . '/../includes/header.php';
?>

<div style="max-width: 520px; margin: 3rem auto; padding: 0 1rem;">
    <div class="card">
        <div class="card-header" style="text-align: center; justify-content: center; flex-direction: column;">
            <h2 class="card-title" style="font-size: 1.4rem;">Create Student Account</h2>
            <p style="font-size: 0.85rem; color: var(--text-muted); margin-top: 0.25rem;">Join SPPI to browse and apply for engineering internships</p>
        </div>

        <div class="card-body">
            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <ul style="margin-left: 1.25rem; margin-bottom: 0;">
                        <?php foreach ($errors as $err): ?>
                            <li><?= sanitize($err) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form action="register.php" method="POST" data-validate>
                <div class="form-group">
                    <label class="form-label" for="full_name">Full Name *</label>
                    <input type="text" id="full_name" name="full_name" class="form-control" value="<?= sanitize($name) ?>" placeholder="e.g. Jane Doe" required>
                </div>

                <div class="form-group">
                    <label class="form-label" for="email">College / Personal Email *</label>
                    <input type="email" id="email" name="email" class="form-control" value="<?= sanitize($email) ?>" placeholder="e.g. jane@student.sppi.edu" required>
                </div>

                <div class="form-group">
                    <label class="form-label" for="department">Department *</label>
                    <select id="department" name="department" class="form-select" required>
                        <option value="">-- Select Department --</option>
                        <option value="Computer Engineering" <?= $department === 'Computer Engineering' ? 'selected' : '' ?>>Computer Engineering</option>
                        <option value="Information Technology" <?= $department === 'Information Technology' ? 'selected' : '' ?>>Information Technology</option>
                        <option value="Electronics Engineering" <?= $department === 'Electronics Engineering' ? 'selected' : '' ?>>Electronics Engineering</option>
                        <option value="Mechanical Engineering" <?= $department === 'Mechanical Engineering' ? 'selected' : '' ?>>Mechanical Engineering</option>
                        <option value="Civil Engineering" <?= $department === 'Civil Engineering' ? 'selected' : '' ?>>Civil Engineering</option>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label" for="semester">Current Semester *</label>
                    <select id="semester" name="semester" class="form-select" required>
                        <?php for ($s = 1; $s <= 8; $s++): ?>
                            <option value="<?= $s ?>" <?= $semester == $s ? 'selected' : '' ?>>Semester <?= $s ?></option>
                        <?php endfor; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label" for="password">Password *</label>
                    <input type="password" id="password" name="password" class="form-control" placeholder="At least 6 characters" data-min-length="6" required>
                </div>

                <div class="form-group">
                    <label class="form-label" for="confirm_password">Confirm Password *</label>
                    <input type="password" id="confirm_password" name="confirm_password" class="form-control" placeholder="Re-enter password" data-match="password" required>
                </div>

                <button type="submit" class="btn btn-primary btn-block" style="margin-top: 1.5rem;">Create Account</button>
            </form>
        </div>

        <div class="card-footer" style="text-align: center; font-size: 0.875rem;">
            Already registered? <a href="login.php" style="font-weight: 600;">Sign In Here</a>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
