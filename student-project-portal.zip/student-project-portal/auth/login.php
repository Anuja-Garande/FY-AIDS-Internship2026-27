<?php
// auth/login.php - Role-based Login Interface
require_once __DIR__ . '/../config/db_connect.php';
require_once __DIR__ . '/../includes/auth_check.php';

if (is_logged_in()) {
    $role = $_SESSION['user_role'] ?? '';
    header('Location: ' . get_dashboard_url_for_role($role));
    exit();
}

$error = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $error = "Please enter both email address and password.";
    } else {
        $pdo = getDB();
        $stmt = $pdo->prepare("SELECT * FROM Users WHERE Email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['Password_Hash'])) {
            if (!$user['Is_Verified']) {
                $error = "Your account is currently unverified. Please contact the portal administrator.";
            } else {
                // Set Session Data
                $_SESSION['user_id']   = $user['User_ID'];
                $_SESSION['user_name'] = $user['Full_Name'];
                $_SESSION['user_email']= $user['Email'];
                $_SESSION['user_role'] = $user['Role'];

                // If Student or Company, fetch specific FK IDs
                if (strcasecmp($user['Role'], 'Student') === 0) {
                    $stmtStud = $pdo->prepare("SELECT Student_ID FROM Students WHERE User_ID = ?");
                    $stmtStud->execute([$user['User_ID']]);
                    $stud = $stmtStud->fetch();
                    $_SESSION['student_id'] = $stud['Student_ID'] ?? null;
                } elseif (strcasecmp($user['Role'], 'Company') === 0) {
                    $stmtComp = $pdo->prepare("SELECT Company_ID FROM Companies WHERE User_ID = ?");
                    $stmtComp->execute([$user['User_ID']]);
                    $comp = $stmtComp->fetch();
                    $_SESSION['company_id'] = $comp['Company_ID'] ?? null;
                }

                set_flash_message('success', 'Welcome back, ' . $user['Full_Name'] . '!');

                header('Location: ' . get_dashboard_url_for_role($user['Role']));
                exit();
            }
        } else {
            $error = "Invalid email address or password combination.";
        }
    }
}

$page_title = "Sign In - SPPI Portal";
require_once __DIR__ . '/../includes/header.php';
?>

<div style="max-width: 900px; margin: 3rem auto; padding: 0 1rem;">
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 2rem; align-items: start;">
        
        <!-- Login Form Card -->
        <div class="card">
            <div class="card-header" style="text-align: center; flex-direction: column; justify-content: center;">
                <h2 class="card-title" style="font-size: 1.4rem;">Portal Login</h2>
                <p style="font-size: 0.85rem; color: var(--text-muted); margin-top: 0.25rem;">Sign in with your registered account credentials</p>
            </div>

            <div class="card-body">
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger">
                        <?= sanitize($error) ?>
                    </div>
                <?php endif; ?>

                <form action="login.php" method="POST" data-validate>
                    <div class="form-group">
                        <label class="form-label" for="email">Email Address *</label>
                        <input type="email" id="email" name="email" class="form-control" value="<?= sanitize($email) ?>" placeholder="user@sppi.edu" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="password">Password *</label>
                        <input type="password" id="password" name="password" class="form-control" placeholder="••••••••" required>
                    </div>

                    <button type="submit" class="btn btn-primary btn-block" style="margin-top: 1.5rem;">Sign In</button>
                </form>
            </div>

            <div class="card-footer" style="text-align: center; font-size: 0.875rem;">
                New Student? <a href="register.php" style="font-weight: 600;">Register Here</a>
            </div>
        </div>

       
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
