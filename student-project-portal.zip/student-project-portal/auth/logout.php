<?php
// auth/logout.php
require_once __DIR__ . '/../includes/auth_check.php';

session_unset();
session_destroy();

session_start();
set_flash_message('info', 'You have been successfully logged out.');
header('Location: ../index.php');
exit();
?>
