-- ====================================================================
-- Student Project Portal for Internship (SPPI) - Database Schema
-- Compatible with MySQL / MariaDB (XAMPP / PHPMyAdmin)
-- ====================================================================

CREATE DATABASE IF NOT EXISTS `sppi_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `sppi_db`;

-- Drop tables if exists (in correct reverse dependency order)
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS `Mentor_Feedback`;
DROP TABLE IF EXISTS `Applications`;
DROP TABLE IF EXISTS `Internships`;
DROP TABLE IF EXISTS `Companies`;
DROP TABLE IF EXISTS `Students`;
DROP TABLE IF EXISTS `Users`;
SET FOREIGN_KEY_CHECKS = 1;

-- 1. Users Table
CREATE TABLE `Users` (
  `User_ID` INT AUTO_INCREMENT PRIMARY KEY,
  `Full_Name` VARCHAR(100) NOT NULL,
  `Email` VARCHAR(150) NOT NULL UNIQUE,
  `Password_Hash` VARCHAR(255) NOT NULL,
  `Role` ENUM('Admin', 'Faculty', 'Student', 'Company') NOT NULL DEFAULT 'Student',
  `Registration_Date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Is_Verified` TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Students Table
CREATE TABLE `Students` (
  `Student_ID` INT AUTO_INCREMENT PRIMARY KEY,
  `User_ID` INT NOT NULL UNIQUE,
  `Department` VARCHAR(100) DEFAULT NULL,
  `Current_Semester` INT DEFAULT 1,
  `Skills` TEXT DEFAULT NULL,
  `Resume_Path` VARCHAR(255) DEFAULT NULL,
  `Mentor_User_ID` INT DEFAULT NULL,
  CONSTRAINT `fk_student_user` FOREIGN KEY (`User_ID`) REFERENCES `Users` (`User_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_student_mentor` FOREIGN KEY (`Mentor_User_ID`) REFERENCES `Users` (`User_ID`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Companies Table
CREATE TABLE `Companies` (
  `Company_ID` INT AUTO_INCREMENT PRIMARY KEY,
  `User_ID` INT NOT NULL UNIQUE,
  `Company_Name` VARCHAR(150) NOT NULL,
  `Industry_Type` VARCHAR(100) DEFAULT NULL,
  `Contact_Number` VARCHAR(20) DEFAULT NULL,
  CONSTRAINT `fk_company_user` FOREIGN KEY (`User_ID`) REFERENCES `Users` (`User_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Internships Table
CREATE TABLE `Internships` (
  `Internship_ID` INT AUTO_INCREMENT PRIMARY KEY,
  `Company_ID` INT NOT NULL,
  `Title` VARCHAR(150) NOT NULL,
  `Description` TEXT NOT NULL,
  `Required_Skills` TEXT DEFAULT NULL,
  `Duration_Weeks` INT NOT NULL DEFAULT 8,
  `Status` ENUM('Open', 'Closed') NOT NULL DEFAULT 'Open',
  `Posted_Date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_internship_company` FOREIGN KEY (`Company_ID`) REFERENCES `Companies` (`Company_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Applications Table
CREATE TABLE `Applications` (
  `Application_ID` INT AUTO_INCREMENT PRIMARY KEY,
  `Student_ID` INT NOT NULL,
  `Internship_ID` INT NOT NULL,
  `Applied_Date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Status` ENUM('Submitted', 'Mentor Review', 'Approved', 'Shortlisted', 'Selected', 'Rejected') NOT NULL DEFAULT 'Submitted',
  CONSTRAINT `fk_app_student` FOREIGN KEY (`Student_ID`) REFERENCES `Students` (`Student_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_app_internship` FOREIGN KEY (`Internship_ID`) REFERENCES `Internships` (`Internship_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. Mentor_Feedback Table
CREATE TABLE `Mentor_Feedback` (
  `Feedback_ID` INT AUTO_INCREMENT PRIMARY KEY,
  `Application_ID` INT NOT NULL,
  `Mentor_User_ID` INT NOT NULL,
  `Remarks` TEXT NOT NULL,
  `Feedback_Date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_feedback_application` FOREIGN KEY (`Application_ID`) REFERENCES `Applications` (`Application_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_feedback_mentor` FOREIGN KEY (`Mentor_User_ID`) REFERENCES `Users` (`User_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ====================================================================
-- SEED DATA (Default Password for all accounts: "Password123")
-- Hash: $2y$10$.sz1ZGolPnpjjPerCkYF0ufq2c7CWtL/8DAtExMzERKibkkzG6dye
-- ====================================================================

-- Insert Users
INSERT INTO `Users` (`User_ID`, `Full_Name`, `Email`, `Password_Hash`, `Role`, `Is_Verified`) VALUES
(1, 'System Administrator', 'admin@sppi.edu', '$2y$10$.sz1ZGolPnpjjPerCkYF0ufq2c7CWtL/8DAtExMzERKibkkzG6dye', 'Admin', 1),
(2, 'Dr. Robert Vance', 'rvance@sppi.edu', '$2y$10$.sz1ZGolPnpjjPerCkYF0ufq2c7CWtL/8DAtExMzERKibkkzG6dye', 'Faculty', 1),
(3, 'Prof. Sarah Jenkins', 'sjenkins@sppi.edu', '$2y$10$.sz1ZGolPnpjjPerCkYF0ufq2c7CWtL/8DAtExMzERKibkkzG6dye', 'Faculty', 1),
(4, 'TechNova Solutions HR', 'recruitment@technova.com', '$2y$10$.sz1ZGolPnpjjPerCkYF0ufq2c7CWtL/8DAtExMzERKibkkzG6dye', 'Company', 1),
(5, 'CyberCloud Systems', 'careers@cybercloud.com', '$2y$10$.sz1ZGolPnpjjPerCkYF0ufq2c7CWtL/8DAtExMzERKibkkzG6dye', 'Company', 1),
(6, 'Alex Johnson', 'alex.j@student.sppi.edu', '$2y$10$.sz1ZGolPnpjjPerCkYF0ufq2c7CWtL/8DAtExMzERKibkkzG6dye', 'Student', 1),
(7, 'Maya Sharma', 'maya.s@student.sppi.edu', '$2y$10$.sz1ZGolPnpjjPerCkYF0ufq2c7CWtL/8DAtExMzERKibkkzG6dye', 'Student', 1),
(8, 'David Miller', 'david.m@student.sppi.edu', '$2y$10$.sz1ZGolPnpjjPerCkYF0ufq2c7CWtL/8DAtExMzERKibkkzG6dye', 'Student', 1);

-- Insert Companies
INSERT INTO `Companies` (`Company_ID`, `User_ID`, `Company_Name`, `Industry_Type`, `Contact_Number`) VALUES
(1, 4, 'TechNova Solutions', 'Software & Cloud Engineering', '+1 (555) 019-2834'),
(2, 5, 'CyberCloud Systems', 'Cybersecurity & Infrastructure', '+1 (555) 088-3921');

-- Insert Students
INSERT INTO `Students` (`Student_ID`, `User_ID`, `Department`, `Current_Semester`, `Skills`, `Resume_Path`, `Mentor_User_ID`) VALUES
(1, 6, 'Computer Engineering', 6, 'PHP, MySQL, JavaScript, HTML5, CSS3, Git', 'uploads/resumes/sample_resume_alex.pdf', 2),
(2, 7, 'Information Technology', 6, 'Python, Data Analytics, React, SQL', 'uploads/resumes/sample_resume_maya.pdf', 2),
(3, 8, 'Electronics Engineering', 4, 'C++, Embedded Systems, IoT, Python', NULL, 3);

-- Insert Internships
INSERT INTO `Internships` (`Internship_ID`, `Company_ID`, `Title`, `Description`, `Required_Skills`, `Duration_Weeks`, `Status`, `Posted_Date`) VALUES
(1, 1, 'Full-Stack Web Developer Intern', 'We are looking for an enthusiastic Web Development Intern to help build responsive web applications using PHP, MySQL, and JavaScript.', 'PHP, MySQL, JavaScript, HTML/CSS', 12, 'Open', NOW()),
(2, 1, 'Cloud Infrastructure Intern', 'Join our DevOps team to deploy and monitor scalable microservices on AWS and Docker environments.', 'Linux, Bash, Docker, AWS Basics', 8, 'Open', NOW()),
(3, 2, 'Cybersecurity & SOC Analyst Intern', 'Assist our SOC team in analyzing network security logs, monitoring threat alerts, and performing vulnerability scans.', 'Networking, Cybersecurity, Python, Wireshark', 10, 'Open', NOW());

-- Insert Sample Applications
INSERT INTO `Applications` (`Application_ID`, `Student_ID`, `Internship_ID`, `Applied_Date`, `Status`) VALUES
(1, 1, 1, NOW() - INTERVAL 5 DAY, 'Mentor Review'),
(2, 2, 1, NOW() - INTERVAL 3 DAY, 'Approved'),
(3, 1, 3, NOW() - INTERVAL 1 DAY, 'Submitted');

-- Insert Sample Mentor Feedback
INSERT INTO `Mentor_Feedback` (`Feedback_ID`, `Application_ID`, `Mentor_User_ID`, `Remarks`, `Feedback_Date`) VALUES
(1, 2, 2, 'Maya has strong credentials and relevant coursework in database management. Recommended for company interview.', NOW() - INTERVAL 2 DAY);
