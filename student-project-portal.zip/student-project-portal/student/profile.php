<?php
// student/profile.php - Profile & Resume Upload
require_once __DIR__ . '/../config/db_connect.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_role('Student');
$user = get_logged_in_user();
$pdo = getDB();

$message = '';
$messageType = '';

// Fetch Student Info
$stmt = $pdo->prepare("SELECT * FROM Students WHERE User_ID = ?");
$stmt->execute([$user['id']]);
$student = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $department = trim($_POST['department'] ?? '');
    $semester   = (int)($_POST['semester'] ?? 1);
    $skills     = trim($_POST['skills'] ?? '');
    $resumePath = $student['Resume_Path'] ?? null;

    // Process Resume File Upload if attached
    if (isset($_FILES['resume']) && $_FILES['resume']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['resume']['tmp_name'];
        $fileName    = $_FILES['resume']['name'];
        $fileSize    = $_FILES['resume']['size'];
        $fileType    = $_FILES['resume']['type'];

        $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        $allowedExtensions = ['pdf', 'doc', 'docx'];

        if (!in_array($fileExtension, $allowedExtensions)) {
            $message = "Invalid file type. Only PDF, DOC, and DOCX files are allowed.";
            $messageType = "danger";
        } elseif ($fileSize > 5 * 1024 * 1024) {
            $message = "File size exceeds limit of 5MB.";
            $messageType = "danger";
        } else {
            $uploadDir = __DIR__ . '/../uploads/resumes/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }

            $newFileName = 'resume_user_' . $user['id'] . '_' . time() . '.' . $fileExtension;
            $destPath = $uploadDir . $newFileName;

            if (move_uploaded_file($fileTmpPath, $destPath)) {
                $resumePath = 'uploads/resumes/' . $newFileName;
            } else {
                $message = "Failed to upload resume file. Please check folder permissions.";
                $messageType = "danger";
            }
        }
    }

    if (empty($messageType) || $messageType === 'success') {
        try {
            $stmtUpdate = $pdo->prepare("
                UPDATE Students 
                SET Department = ?, Current_Semester = ?, Skills = ?, Resume_Path = ?
                WHERE User_ID = ?
            ");
            $stmtUpdate->execute([$department, $semester, $skills, $resumePath, $user['id']]);

            set_flash_message('success', 'Profile and resume updated successfully!');
            header('Location: profile.php');
            exit();
        } catch (Exception $e) {
            $message = "Database update error: " . $e->getMessage();
            $messageType = "danger";
        }
    }
}

$page_title = "Student Profile & Resume - SPPI Portal";
$active_page = "profile";
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
    <div>
        <h1 class="page-title">Student Profile & Resume</h1>
        <p class="page-subtitle">Keep your academic information and resume up to date for recruiters</p>
    </div>
</div>

<?php if ($message): ?>
    <div class="alert alert-<?= $messageType ?>">
        <?= sanitize($message) ?>
    </div>
<?php endif; ?>

<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 1.5rem;">
    
    <!-- Profile Form -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Academic & Technical Details</h3>
        </div>
        <div class="card-body">
            <form action="profile.php" method="POST" enctype="multipart/form-data" data-validate>
                
                <div class="form-group">
                    <label class="form-label">Full Name</label>
                    <input type="text" class="form-control" value="<?= sanitize($user['name']) ?>" disabled readonly style="background-color: var(--surface-alt);">
                </div>

                <div class="form-group">
                    <label class="form-label">Email Address</label>
                    <input type="email" class="form-control" value="<?= sanitize($user['email']) ?>" disabled readonly style="background-color: var(--surface-alt);">
                </div>

                <div class="form-group">
                    <label class="form-label" for="department">Department *</label>
                    <select id="department" name="department" class="form-select" required>
                        <option value="Computer Engineering" <?= ($student['Department'] ?? '') === 'Computer Engineering' ? 'selected' : '' ?>>Computer Engineering</option>
                        <option value="Information Technology" <?= ($student['Department'] ?? '') === 'Information Technology' ? 'selected' : '' ?>>Information Technology</option>
                        <option value="Electronics Engineering" <?= ($student['Department'] ?? '') === 'Electronics Engineering' ? 'selected' : '' ?>>Electronics Engineering</option>
                        <option value="Mechanical Engineering" <?= ($student['Department'] ?? '') === 'Mechanical Engineering' ? 'selected' : '' ?>>Mechanical Engineering</option>
                        <option value="Civil Engineering" <?= ($student['Department'] ?? '') === 'Civil Engineering' ? 'selected' : '' ?>>Civil Engineering</option>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label" for="semester">Current Semester *</label>
                    <select id="semester" name="semester" class="form-select" required>
                        <?php for ($s = 1; $s <= 8; $s++): ?>
                            <option value="<?= $s ?>" <?= ($student['Current_Semester'] ?? 1) == $s ? 'selected' : '' ?>>Semester <?= $s ?></option>
                        <?php endfor; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label" for="skills">Technical Skills & Competencies</label>
                    <textarea id="skills" name="skills" class="form-control" rows="4" placeholder="e.g. PHP, MySQL, Python, Data Analysis, JavaScript, Git, AWS"><?= sanitize($student['Skills'] ?? '') ?></textarea>
                    <span class="form-text">Separate skills with commas.</span>
                </div>

                <div class="form-group">
                    <label class="form-label" for="resume">Upload Resume (PDF, DOC, DOCX - Max 5MB)</label>
                    <input type="file" id="resume" name="resume" class="form-control" accept=".pdf,.doc,.docx">
                </div>

                <button type="submit" class="btn btn-primary btn-block" style="margin-top: 1rem;">Save Profile & Resume</button>
            </form>
        </div>
    </div>

    <!-- Resume Card & Status -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Uploaded Resume File</h3>
        </div>
        <div class="card-body">
            <?php if (!empty($student['Resume_Path'])): ?>
                <div style="text-align: center; padding: 2rem 1rem;">
                    <div style="font-size: 3rem; margin-bottom: 1rem;">📄</div>
                    <h4 style="font-size: 1.1rem; font-weight: 600; color: var(--primary-900);">Resume Uploaded</h4>
                    <p style="font-size: 0.85rem; color: var(--text-muted); margin-bottom: 1.5rem;">
                        File path: <code><?= sanitize($student['Resume_Path']) ?></code>
                    </p>
                    
                    <a href="<?= get_base_url() . sanitize($student['Resume_Path']) ?>" target="_blank" class="btn btn-outline">
                        👁️ View / Download Resume
                    </a>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <div class="empty-state-icon">📁</div>
                    <div class="empty-state-title">No Resume Uploaded</div>
                    <p class="empty-state-desc">You have not uploaded a resume file yet. Use the form on the left to upload your latest CV.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
