<?php
// student/my_applications.php - Track My Internship Applications
require_once __DIR__ . '/../config/db_connect.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_role('Student');
$user = get_logged_in_user();
$pdo = getDB();

// Get Student FK ID
$stmtStud = $pdo->prepare("SELECT Student_ID FROM Students WHERE User_ID = ?");
$stmtStud->execute([$user['id']]);
$student = $stmtStud->fetch();
$studentId = $student['Student_ID'] ?? 0;

// Fetch Applications with Mentor Feedback
$stmtApps = $pdo->prepare("
    SELECT a.*, i.Title, i.Duration_Weeks, c.Company_Name, c.Industry_Type,
           mf.Remarks as Mentor_Remarks, mf.Feedback_Date, u.Full_Name as Mentor_Name
    FROM Applications a
    JOIN Internships i ON a.Internship_ID = i.Internship_ID
    JOIN Companies c ON i.Company_ID = c.Company_ID
    LEFT JOIN Mentor_Feedback mf ON a.Application_ID = mf.Application_ID
    LEFT JOIN Users u ON mf.Mentor_User_ID = u.User_ID
    WHERE a.Student_ID = ?
    ORDER BY a.Applied_Date DESC
");
$stmtApps->execute([$studentId]);
$applications = $stmtApps->fetchAll();

$page_title = "My Applications - SPPI Portal";
$active_page = "applications";
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
    <div>
        <h1 class="page-title">My Internship Applications</h1>
        <p class="page-subtitle">Track real-time mentor approvals and company recruitment progress</p>
    </div>
    <div>
        <a href="browse_internships.php" class="btn btn-primary">+ Apply for More</a>
    </div>
</div>

<?php if (empty($applications)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📄</div>
        <div class="empty-state-title">No Applications Found</div>
        <p class="empty-state-desc">You have not submitted any internship applications yet.</p>
        <a href="browse_internships.php" class="btn btn-primary">Browse Openings</a>
    </div>
<?php else: ?>
    <div style="display: flex; flex-direction: column; gap: 1.5rem;">
        <?php foreach ($applications as $app): ?>
            <div class="card">
                <div class="card-header">
                    <div>
                        <span class="badge badge-info" style="margin-bottom: 0.25rem;"><?= sanitize($app['Industry_Type']) ?></span>
                        <h3 class="card-title" style="font-size: 1.2rem;"><?= sanitize($app['Title']) ?></h3>
                        <p style="font-size: 0.85rem; color: var(--accent-600); font-weight: 600; margin-top: 0.15rem;">🏢 <?= sanitize($app['Company_Name']) ?></p>
                    </div>
                    <div style="text-align: right;">
                        <span style="font-size: 0.8rem; color: var(--text-muted); display: block; margin-bottom: 0.25rem;">Current Status:</span>
                        <?= render_status_badge($app['Status']) ?>
                    </div>
                </div>

                <div class="card-body">
                    <!-- Status Progress Timeline Indicator -->
                    <div style="background-color: var(--surface-alt); padding: 1rem; border-radius: var(--radius-sm); margin-bottom: 1.25rem;">
                        <div style="display: flex; justify-content: space-between; font-size: 0.75rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; color: var(--text-muted); margin-bottom: 0.5rem;">
                            <span>1. Submitted</span>
                            <span>2. Mentor Review</span>
                            <span>3. Faculty Approved</span>
                            <span>4. Shortlisted / Selected</span>
                        </div>
                        
                        <?php
                        $progressWidth = '25%';
                        if ($app['Status'] === 'Mentor Review') $progressWidth = '50%';
                        elseif ($app['Status'] === 'Approved') $progressWidth = '75%';
                        elseif (in_array($app['Status'], ['Shortlisted', 'Selected'])) $progressWidth = '100%';
                        elseif ($app['Status'] === 'Rejected') $progressWidth = '100%';
                        ?>
                        
                        <div style="height: 8px; background-color: var(--border-color); border-radius: var(--radius-full); overflow: hidden;">
                            <div style="height: 100%; width: <?= $progressWidth ?>; background-color: <?= $app['Status'] === 'Rejected' ? 'var(--danger-600)' : 'var(--accent-600)' ?>; transition: width 0.3s ease;"></div>
                        </div>
                    </div>

                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 1rem; font-size: 0.875rem; margin-bottom: 1rem;">
                        <div>
                            <span style="color: var(--text-muted);">Application ID:</span> <strong>#APP-<?= (int)$app['Application_ID'] ?></strong>
                        </div>
                        <div>
                            <span style="color: var(--text-muted);">Submitted On:</span> <strong><?= date('M d, Y', strtotime($app['Applied_Date'])) ?></strong>
                        </div>
                        <div>
                            <span style="color: var(--text-muted);">Duration:</span> <strong><?= (int)$app['Duration_Weeks'] ?> Weeks</strong>
                        </div>
                    </div>

                    <!-- Mentor Feedback / Remarks section -->
                    <?php if (!empty($app['Mentor_Remarks'])): ?>
                        <div style="border-left: 3px solid var(--accent-600); background-color: var(--accent-50); padding: 0.875rem 1rem; border-radius: 0 var(--radius-sm) var(--radius-sm) 0; margin-top: 1rem;">
                            <strong style="font-size: 0.85rem; color: var(--accent-600); display: block; margin-bottom: 0.25rem;">
                                💬 Faculty Mentor Remarks (by <?= sanitize($app['Mentor_Name']) ?> on <?= date('M d, Y', strtotime($app['Feedback_Date'])) ?>):
                            </strong>
                            <p style="font-size: 0.875rem; color: var(--primary-900); margin: 0;">
                                "<?= sanitize($app['Mentor_Remarks']) ?>"
                            </p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
