<?php
// student/browse_internships.php - Internship Listings & Search
require_once __DIR__ . '/../config/db_connect.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_role('Student');
$user = get_logged_in_user();
$pdo = getDB();

// Get Student FK ID
$stmtStud = $pdo->prepare("SELECT Student_ID FROM Students WHERE User_ID = ?");
$stmtStud->execute([$user['id']]);
$student = $stmtStud->fetch();
$studentId = $student['Student_ID'] ?? 0;

// Search & Filter parameters
$search = trim($_GET['search'] ?? '');

$query = "
    SELECT i.*, c.Company_Name, c.Industry_Type,
           (SELECT Application_ID FROM Applications WHERE Student_ID = ? AND Internship_ID = i.Internship_ID) as Applied_App_ID,
           (SELECT Status FROM Applications WHERE Student_ID = ? AND Internship_ID = i.Internship_ID) as App_Status
    FROM Internships i
    JOIN Companies c ON i.Company_ID = c.Company_ID
    WHERE i.Status = 'Open'
";
$params = [$studentId, $studentId];

if (!empty($search)) {
    $query .= " AND (i.Title LIKE ? OR i.Required_Skills LIKE ? OR c.Company_Name LIKE ?)";
    $term = '%' . $search . '%';
    $params[] = $term;
    $params[] = $term;
    $params[] = $term;
}

$query .= " ORDER BY i.Posted_Date DESC";

$stmtListings = $pdo->prepare($query);
$stmtListings->execute($params);
$listings = $stmtListings->fetchAll();

$page_title = "Browse Internships - SPPI Portal";
$active_page = "browse";
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
    <div>
        <h1 class="page-title">Browse Internships</h1>
        <p class="page-subtitle">Discover active internship opportunities posted by industry partner companies</p>
    </div>
</div>

<!-- Search & Filter Bar -->
<div class="card" style="margin-bottom: 2rem;">
    <div class="card-body" style="padding: 1rem 1.25rem;">
        <form action="browse_internships.php" method="GET" style="display: flex; gap: 1rem; flex-wrap: wrap;">
            <div style="flex: 1; min-width: 240px;">
                <input type="text" name="search" class="form-control" placeholder="Search by title, skills (e.g. PHP, React), or company name..." value="<?= sanitize($search) ?>">
            </div>
            <div>
                <button type="submit" class="btn btn-primary">Search Listings</button>
                <?php if (!empty($search)): ?>
                    <a href="browse_internships.php" class="btn btn-secondary">Clear Search</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>

<!-- Listings Cards Grid -->
<?php if (empty($listings)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">🔍</div>
        <div class="empty-state-title">No Internships Found</div>
        <p class="empty-state-desc">There are no open internship opportunities matching your search criteria at this time.</p>
    </div>
<?php else: ?>
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(340px, 1fr)); gap: 1.5rem;">
        <?php foreach ($listings as $item): ?>
            <div class="card" style="display: flex; flex-direction: column; height: 100%;">
                <div class="card-header">
                    <div>
                        <span class="badge badge-info" style="margin-bottom: 0.25rem;"><?= sanitize($item['Industry_Type'] ?? 'Technology') ?></span>
                        <h3 class="card-title" style="font-size: 1.15rem;"><?= sanitize($item['Title']) ?></h3>
                    </div>
                </div>

                <div class="card-body" style="flex: 1;">
                    <div style="font-size: 0.9rem; font-weight: 600; color: var(--accent-600); margin-bottom: 0.75rem;">
                        🏢 <?= sanitize($item['Company_Name']) ?>
                    </div>

                    <p style="font-size: 0.875rem; color: var(--text-muted); margin-bottom: 1rem; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden;">
                        <?= sanitize($item['Description']) ?>
                    </p>

                    <div style="margin-bottom: 0.75rem; font-size: 0.85rem;">
                        <strong>Required Skills:</strong><br>
                        <span style="color: var(--primary-800);"><?= sanitize($item['Required_Skills'] ?? 'General Engineering') ?></span>
                    </div>

                    <div style="display: flex; gap: 1rem; font-size: 0.8rem; color: var(--text-muted);">
                        <span>⏱️ Duration: <strong><?= (int)$item['Duration_Weeks'] ?> Weeks</strong></span>
                        <span>📅 Posted: <strong><?= date('M d, Y', strtotime($item['Posted_Date'])) ?></strong></span>
                    </div>
                </div>

                <div class="card-footer" style="display: flex; justify-content: space-between; align-items: center;">
                    <?php if ($item['Applied_App_ID']): ?>
                        <div style="display: flex; align-items: center; gap: 0.5rem;">
                            <span style="font-size: 0.85rem; font-weight: 500; color: var(--text-muted);">Status:</span>
                            <?= render_status_badge($item['App_Status']) ?>
                        </div>
                        <a href="my_applications.php" class="btn btn-sm btn-secondary">Track Application</a>
                    <?php else: ?>
                        <span class="badge badge-success">Accepting Applications</span>
                        <a href="apply.php?id=<?= $item['Internship_ID'] ?>" class="btn btn-sm btn-primary">Apply Now →</a>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
