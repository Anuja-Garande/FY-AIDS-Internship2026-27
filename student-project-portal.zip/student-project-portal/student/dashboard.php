<?php
// student/dashboard.php - Student Main Dashboard
require_once __DIR__ . '/../config/db_connect.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_role('Student');
$user = get_logged_in_user();
$pdo = getDB();

// Fetch Student & Profile details
$stmtStud = $pdo->prepare("
    SELECT s.*, u.Full_Name as Mentor_Name, u.Email as Mentor_Email
    FROM Students s
    LEFT JOIN Users u ON s.Mentor_User_ID = u.User_ID
    WHERE s.User_ID = ?
");
$stmtStud->execute([$user['id']]);
$student = $stmtStud->fetch();

$studentId = $student['Student_ID'] ?? 0;

// Application Stats
$totalSubmitted = 0;
$inReview = 0;
$approvedCount = 0;
$selectedCount = 0;

if ($studentId) {
    $stmtStats = $pdo->prepare("
        SELECT Status, COUNT(*) as cnt 
        FROM Applications 
        WHERE Student_ID = ? 
        GROUP BY Status
    ");
    $stmtStats->execute([$studentId]);
    $statusRows = $stmtStats->fetchAll();

    foreach ($statusRows as $row) {
        if ($row['Status'] === 'Submitted') $totalSubmitted += $row['cnt'];
        elseif ($row['Status'] === 'Mentor Review') $inReview += $row['cnt'];
        elseif (in_array($row['Status'], ['Approved', 'Shortlisted'])) $approvedCount += $row['cnt'];
        elseif ($row['Status'] === 'Selected') $selectedCount += $row['cnt'];
    }
}

// Fetch recent applications
$stmtApps = $pdo->prepare("
    SELECT a.*, i.Title, c.Company_Name
    FROM Applications a
    JOIN Internships i ON a.Internship_ID = i.Internship_ID
    JOIN Companies c ON i.Company_ID = c.Company_ID
    WHERE a.Student_ID = ?
    ORDER BY a.Applied_Date DESC
    LIMIT 5
");
$stmtApps->execute([$studentId]);
$recentApps = $stmtApps->fetchAll();

// Fetch featured open internships
$stmtFeatured = $pdo->query("
    SELECT i.*, c.Company_Name
    FROM Internships i
    JOIN Companies c ON i.Company_ID = c.Company_ID
    WHERE i.Status = 'Open'
    ORDER BY i.Posted_Date DESC
    LIMIT 4
");
$featuredListings = $stmtFeatured->fetchAll();

$page_title = "Student Dashboard - SPPI Portal";
$active_page = "dashboard";
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
    <div>
        <h1 class="page-title">Welcome back, <?= sanitize($user['name']) ?>! 👋</h1>
        <p class="page-subtitle"><?= sanitize($student['Department'] ?? 'Engineering Student') ?> • Semester <?= sanitize($student['Current_Semester'] ?? 1) ?></p>
    </div>
    <div>
        <a href="browse_internships.php" class="btn btn-primary">🔍 Browse Internships</a>
    </div>
</div>

<!-- Profile Banner Alert if Resume/Skills missing -->
<?php if (empty($student['Skills']) || empty($student['Resume_Path'])): ?>
    <div class="alert alert-warning">
        <div>
            <strong>⚠️ Profile Incomplete:</strong> Please complete your technical skills and upload a resume PDF to apply for internships.
        </div>
        <a href="profile.php" class="btn btn-sm btn-outline" style="border-color: var(--warning-700); color: var(--warning-700);">Update Profile</a>
    </div>
<?php endif; ?>

<!-- Stats Grid -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-content">
            <span class="stat-value"><?= $totalSubmitted ?></span>
            <span class="stat-label">Applications Submitted</span>
        </div>
        <div class="stat-icon info">📝</div>
    </div>

    <div class="stat-card">
        <div class="stat-content">
            <span class="stat-value"><?= $inReview ?></span>
            <span class="stat-label">In Mentor Review</span>
        </div>
        <div class="stat-icon warning">⏳</div>
    </div>

    <div class="stat-card">
        <div class="stat-content">
            <span class="stat-value"><?= $approvedCount ?></span>
            <span class="stat-label">Faculty Approved</span>
        </div>
        <div class="stat-icon primary">👍</div>
    </div>

    <div class="stat-card">
        <div class="stat-content">
            <span class="stat-value"><?= $selectedCount ?></span>
            <span class="stat-label">Internship Selections</span>
        </div>
        <div class="stat-icon success">🎉</div>
    </div>
</div>

<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(340px, 1fr)); gap: 1.5rem;">
    
    <!-- My Recent Applications -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">My Recent Applications</h3>
            <a href="my_applications.php" style="font-size: 0.85rem; font-weight: 500;">View All →</a>
        </div>
        <div class="card-body" style="padding: 0;">
            <?php if (empty($recentApps)): ?>
                <div class="empty-state" style="border: none;">
                    <div class="empty-state-icon">📄</div>
                    <div class="empty-state-title">No Applications Yet</div>
                    <p class="empty-state-desc">You haven't submitted any internship applications yet.</p>
                    <a href="browse_internships.php" class="btn btn-sm btn-primary">Explore Openings</a>
                </div>
            <?php else: ?>
                <div class="table-responsive" style="border: none;">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Role & Company</th>
                                <th>Applied Date</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recentApps as $app): ?>
                                <tr>
                                    <td>
                                        <strong><?= sanitize($app['Title']) ?></strong><br>
                                        <span style="font-size: 0.8rem; color: var(--text-muted);"><?= sanitize($app['Company_Name']) ?></span>
                                    </td>
                                    <td style="font-size: 0.85rem; color: var(--text-muted);">
                                        <?= date('M d, Y', strtotime($app['Applied_Date'])) ?>
                                    </td>
                                    <td>
                                        <?= render_status_badge($app['Status']) ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Mentor Info Card -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Assigned Faculty Mentor</h3>
        </div>
        <div class="card-body">
            <?php if (!empty($student['Mentor_Name'])): ?>
                <div style="display: flex; align-items: center; gap: 1rem;">
                    <div class="user-avatar" style="width: 48px; height: 48px; font-size: 1.2rem;">
                        👨‍🏫
                    </div>
                    <div>
                        <h4 style="font-size: 1.05rem; font-weight: 600; color: var(--primary-900);"><?= sanitize($student['Mentor_Name']) ?></h4>
                        <p style="font-size: 0.85rem; color: var(--text-muted);"><?= sanitize($student['Mentor_Email']) ?></p>
                        <span class="badge badge-success" style="margin-top: 0.25rem;">Active Mentor</span>
                    </div>
                </div>
                <hr style="margin: 1.25rem 0; border: none; border-top: 1px solid var(--border-color);">
                <p style="font-size: 0.85rem; color: var(--text-muted);">
                    Your assigned faculty mentor reviews and verifies your internship applications before they are forwarded to companies.
                </p>
            <?php else: ?>
                <div class="empty-state" style="border: none; padding: 1.5rem 1rem;">
                    <div class="empty-state-title">No Mentor Assigned Yet</div>
                    <p class="empty-state-desc">Admin will assign a faculty mentor from your department soon.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
