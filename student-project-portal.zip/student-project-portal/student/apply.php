<?php
// student/apply.php - Submit Internship Application
require_once __DIR__ . '/../config/db_connect.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_role('Student');
$user = get_logged_in_user();
$pdo = getDB();

$internshipId = (int)($_GET['id'] ?? 0);

// Fetch Student Profile
$stmtStud = $pdo->prepare("SELECT * FROM Students WHERE User_ID = ?");
$stmtStud->execute([$user['id']]);
$student = $stmtStud->fetch();
$studentId = $student['Student_ID'] ?? 0;

// Fetch Internship Details
$stmtInt = $pdo->prepare("
    SELECT i.*, c.Company_Name, c.Industry_Type, c.Contact_Number
    FROM Internships i
    JOIN Companies c ON i.Company_ID = c.Company_ID
    WHERE i.Internship_ID = ? AND i.Status = 'Open'
");
$stmtInt->execute([$internshipId]);
$internship = $stmtInt->fetch();

if (!$internship) {
    set_flash_message('danger', 'The requested internship listing is closed or does not exist.');
    header('Location: browse_internships.php');
    exit();
}

// Check duplicate application
$stmtCheck = $pdo->prepare("SELECT Application_ID FROM Applications WHERE Student_ID = ? AND Internship_ID = ?");
$stmtCheck->execute([$studentId, $internshipId]);
if ($stmtCheck->fetch()) {
    set_flash_message('warning', 'You have already submitted an application for this internship listing.');
    header('Location: my_applications.php');
    exit();
}

// Process Application Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($student['Resume_Path'])) {
        set_flash_message('danger', 'You must upload a resume before applying. Please update your profile.');
        header('Location: profile.php');
        exit();
    }

    try {
        $stmtApp = $pdo->prepare("
            INSERT INTO Applications (Student_ID, Internship_ID, Applied_Date, Status)
            VALUES (?, ?, NOW(), 'Submitted')
        ");
        $stmtApp->execute([$studentId, $internshipId]);

        set_flash_message('success', 'Your application has been successfully submitted! It is now queued for your Faculty Mentor to review.');
        header('Location: my_applications.php');
        exit();
    } catch (Exception $e) {
        set_flash_message('danger', 'Application error: ' . $e->getMessage());
    }
}

$page_title = "Apply for " . sanitize($internship['Title']) . " - SPPI Portal";
$active_page = "browse";
require_once __DIR__ . '/../includes/header.php';
?>

<div style="max-width: 760px; margin: 2rem auto;">
    <div class="card">
        <div class="card-header">
            <div>
                <span class="badge badge-info" style="margin-bottom: 0.25rem;"><?= sanitize($internship['Industry_Type']) ?></span>
                <h1 class="card-title" style="font-size: 1.4rem;"><?= sanitize($internship['Title']) ?></h1>
                <p style="font-size: 0.9rem; color: var(--accent-600); font-weight: 600; margin-top: 0.25rem;">🏢 <?= sanitize($internship['Company_Name']) ?></p>
            </div>
        </div>

        <div class="card-body">
            <h4 style="font-size: 1rem; font-weight: 600; margin-bottom: 0.5rem;">Job Description</h4>
            <p style="font-size: 0.9rem; color: var(--text-muted); line-height: 1.6; margin-bottom: 1.5rem;">
                <?= nl2br(sanitize($internship['Description'])) ?>
            </p>

            <div style="background-color: var(--surface-alt); padding: 1.25rem; border-radius: var(--radius-sm); margin-bottom: 1.5rem;">
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; font-size: 0.875rem;">
                    <div>
                        <strong>Required Skills:</strong><br>
                        <span style="color: var(--primary-900);"><?= sanitize($internship['Required_Skills']) ?></span>
                    </div>
                    <div>
                        <strong>Duration:</strong><br>
                        <span style="color: var(--primary-900);"><?= (int)$internship['Duration_Weeks'] ?> Weeks</span>
                    </div>
                </div>
            </div>

            <h4 style="font-size: 1rem; font-weight: 600; margin-bottom: 0.75rem;">Review Your Application Credentials</h4>
            
            <div style="border: 1px solid var(--border-color); border-radius: var(--radius-sm); padding: 1rem; margin-bottom: 1.5rem;">
                <div style="font-size: 0.875rem; margin-bottom: 0.5rem;">
                    <strong>Applicant Name:</strong> <?= sanitize($user['name']) ?> (<?= sanitize($student['Department']) ?>, Sem <?= (int)$student['Current_Semester'] ?>)
                </div>
                <div style="font-size: 0.875rem; margin-bottom: 0.5rem;">
                    <strong>Email:</strong> <?= sanitize($user['email']) ?>
                </div>
                <div style="font-size: 0.875rem;">
                    <strong>Attached Resume:</strong> 
                    <?php if (!empty($student['Resume_Path'])): ?>
                        <span style="color: var(--success-700); font-weight: 600;">✓ <?= sanitize($student['Resume_Path']) ?></span>
                    <?php else: ?>
                        <span style="color: var(--danger-600); font-weight: 600;">❌ No resume attached. <a href="profile.php">Upload now</a></span>
                    <?php endif; ?>
                </div>
            </div>

            <?php if (empty($student['Resume_Path'])): ?>
                <div class="alert alert-warning">
                    You cannot submit your application until you upload a resume file on your <a href="profile.php" style="font-weight: 600;">Profile page</a>.
                </div>
            <?php endif; ?>

            <form action="apply.php?id=<?= $internshipId ?>" method="POST">
                <div style="display: flex; gap: 1rem; justify-content: flex-end;">
                    <a href="browse_internships.php" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-primary" <?= empty($student['Resume_Path']) ? 'disabled' : '' ?>>
                        Confirm & Submit Application →
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
