<?php
// faculty/review_applications.php - Application Review Queue
require_once __DIR__ . '/../config/db_connect.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_role('Faculty');
$user = get_logged_in_user();
$pdo = getDB();

$filter = trim($_GET['filter'] ?? 'pending');

$query = "
    SELECT a.*, i.Title, i.Duration_Weeks, c.Company_Name, u.Full_Name as Student_Name, u.Email as Student_Email, s.Department, s.Current_Semester, s.Skills, s.Resume_Path,
           mf.Remarks as Mentor_Remarks
    FROM Applications a
    JOIN Internships i ON a.Internship_ID = i.Internship_ID
    JOIN Companies c ON i.Company_ID = c.Company_ID
    JOIN Students s ON a.Student_ID = s.Student_ID
    JOIN Users u ON s.User_ID = u.User_ID
    LEFT JOIN Mentor_Feedback mf ON a.Application_ID = mf.Application_ID
    WHERE s.Mentor_User_ID = ?
";
$params = [$user['id']];

if ($filter === 'pending') {
    $query .= " AND a.Status IN ('Submitted', 'Mentor Review')";
} elseif ($filter === 'approved') {
    $query .= " AND a.Status IN ('Approved', 'Shortlisted', 'Selected')";
} elseif ($filter === 'rejected') {
    $query .= " AND a.Status = 'Rejected'";
}

$query .= " ORDER BY a.Applied_Date DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$applications = $stmt->fetchAll();

$page_title = "Review Applications - Faculty Portal";
$active_page = "review";
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
    <div>
        <h1 class="page-title">Student Application Review Queue</h1>
        <p class="page-subtitle">Verify student credentials and approve applications before company shortlisting</p>
    </div>
</div>

<!-- Filter Tabs -->
<div style="display: flex; gap: 0.5rem; margin-bottom: 1.5rem; border-bottom: 1px solid var(--border-color); padding-bottom: 0.75rem;">
    <a href="review_applications.php?filter=pending" class="btn btn-sm <?= $filter === 'pending' ? 'btn-primary' : 'btn-secondary' ?>">
        ⏳ Pending Review
    </a>
    <a href="review_applications.php?filter=approved" class="btn btn-sm <?= $filter === 'approved' ? 'btn-primary' : 'btn-secondary' ?>">
        👍 Approved
    </a>
    <a href="review_applications.php?filter=rejected" class="btn btn-sm <?= $filter === 'rejected' ? 'btn-primary' : 'btn-secondary' ?>">
        ❌ Rejected
    </a>
    <a href="review_applications.php?filter=all" class="btn btn-sm <?= $filter === 'all' ? 'btn-primary' : 'btn-secondary' ?>">
        📋 All Applications
    </a>
</div>

<?php if (empty($applications)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📁</div>
        <div class="empty-state-title">No Applications Found</div>
        <p class="empty-state-desc">There are no student applications matching the selected filter criteria.</p>
    </div>
<?php else: ?>
    <div class="table-responsive">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>App ID</th>
                    <th>Student Details</th>
                    <th>Internship & Company</th>
                    <th>Skills & Resume</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($applications as $item): ?>
                    <tr>
                        <td style="font-weight: 600; font-size: 0.85rem; color: var(--text-muted);">
                            #APP-<?= (int)$item['Application_ID'] ?>
                        </td>
                        <td>
                            <strong><?= sanitize($item['Student_Name']) ?></strong><br>
                            <span style="font-size: 0.8rem; color: var(--text-muted);"><?= sanitize($item['Department']) ?> (Sem <?= (int)$item['Current_Semester'] ?>)</span>
                        </td>
                        <td>
                            <strong><?= sanitize($item['Title']) ?></strong><br>
                            <span style="font-size: 0.8rem; color: var(--accent-600); font-weight: 500;"><?= sanitize($item['Company_Name']) ?></span>
                        </td>
                        <td>
                            <span style="font-size: 0.8rem; display: block; max-width: 200px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="<?= sanitize($item['Skills']) ?>">
                                🛠️ <?= sanitize($item['Skills'] ?? 'Not specified') ?>
                            </span>
                            <?php if (!empty($item['Resume_Path'])): ?>
                                <a href="<?= get_base_url() . sanitize($item['Resume_Path']) ?>" target="_blank" style="font-size: 0.8rem; font-weight: 600;">📄 View Resume PDF</a>
                            <?php else: ?>
                                <span style="font-size: 0.8rem; color: var(--danger-600);">No Resume File</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?= render_status_badge($item['Status']) ?>
                        </td>
                        <td>
                            <a href="give_feedback.php?id=<?= $item['Application_ID'] ?>" class="btn btn-sm btn-primary">
                                Review & Feedback
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
