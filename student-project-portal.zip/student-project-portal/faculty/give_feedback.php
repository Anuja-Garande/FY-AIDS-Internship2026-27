<?php
// faculty/give_feedback.php - Faculty Mentor Decision & Written Feedback
require_once __DIR__ . '/../config/db_connect.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_role('Faculty');
$user = get_logged_in_user();
$pdo = getDB();

$appId = (int)($_GET['id'] ?? 0);

// Fetch Application & Student details
$stmt = $pdo->prepare("
    SELECT a.*, i.Title, i.Description as Job_Desc, i.Required_Skills, c.Company_Name,
           u.Full_Name as Student_Name, u.Email as Student_Email,
           s.Department, s.Current_Semester, s.Skills as Student_Skills, s.Resume_Path,
           mf.Remarks, mf.Feedback_ID
    FROM Applications a
    JOIN Internships i ON a.Internship_ID = i.Internship_ID
    JOIN Companies c ON i.Company_ID = c.Company_ID
    JOIN Students s ON a.Student_ID = s.Student_ID
    JOIN Users u ON s.User_ID = u.User_ID
    LEFT JOIN Mentor_Feedback mf ON a.Application_ID = mf.Application_ID
    WHERE a.Application_ID = ? AND s.Mentor_User_ID = ?
");
$stmt->execute([$appId, $user['id']]);
$application = $stmt->fetch();

if (!$application) {
    set_flash_message('danger', 'Application record not found or not assigned to your mentorship.');
    header('Location: review_applications.php');
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $status = trim($_POST['status'] ?? '');
    $remarks = trim($_POST['remarks'] ?? '');

    $allowedStatuses = ['Approved', 'Mentor Review', 'Rejected'];

    if (!in_array($status, $allowedStatuses)) {
        $error = "Please select a valid review decision status.";
    } elseif (empty($remarks)) {
        $error = "Please provide written remarks or feedback explanation for the student.";
    } else {
        try {
            $pdo->beginTransaction();

            // 1. Update Application status
            $stmtUpdateApp = $pdo->prepare("UPDATE Applications SET Status = ? WHERE Application_ID = ?");
            $stmtUpdateApp->execute([$status, $appId]);

            // 2. Insert or Update Mentor_Feedback table
            if ($application['Feedback_ID']) {
                $stmtFb = $pdo->prepare("
                    UPDATE Mentor_Feedback 
                    SET Remarks = ?, Feedback_Date = NOW() 
                    WHERE Feedback_ID = ?
                ");
                $stmtFb->execute([$remarks, $application['Feedback_ID']]);
            } else {
                $stmtFb = $pdo->prepare("
                    INSERT INTO Mentor_Feedback (Application_ID, Mentor_User_ID, Remarks, Feedback_Date)
                    VALUES (?, ?, ?, NOW())
                ");
                $stmtFb->execute([$appId, $user['id'], $remarks]);
            }

            $pdo->commit();

            set_flash_message('success', 'Faculty review & remarks submitted successfully!');
            header('Location: review_applications.php');
            exit();

        } catch (Exception $e) {
            $pdo->rollBack();
            $error = "Failed to submit decision: " . $e->getMessage();
        }
    }
}

$page_title = "Evaluate Application #APP-" . $appId . " - Faculty Portal";
$active_page = "review";
require_once __DIR__ . '/../includes/header.php';
?>

<div style="max-width: 800px; margin: 2rem auto;">
    <div class="card">
        <div class="card-header">
            <div>
                <span class="badge badge-info" style="margin-bottom: 0.25rem;">Application #APP-<?= $appId ?></span>
                <h1 class="card-title" style="font-size: 1.3rem;">Faculty Mentor Evaluation</h1>
            </div>
            <div>
                <?= render_status_badge($application['Status']) ?>
            </div>
        </div>

        <div class="card-body">
            <?php if ($error): ?>
                <div class="alert alert-danger"><?= sanitize($error) ?></div>
            <?php endif; ?>

            <!-- Student Profile Card Header -->
            <div style="background-color: var(--surface-alt); padding: 1.25rem; border-radius: var(--radius-sm); margin-bottom: 1.5rem; border: 1px solid var(--border-color);">
                <h3 style="font-size: 1.1rem; font-weight: 700; color: var(--primary-900); margin-bottom: 0.5rem;">
                    👨‍🎓 <?= sanitize($application['Student_Name']) ?>
                </h3>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; font-size: 0.875rem;">
                    <div>
                        <strong>Department:</strong> <?= sanitize($application['Department']) ?><br>
                        <strong>Semester:</strong> <?= (int)$application['Current_Semester'] ?><br>
                        <strong>Email:</strong> <?= sanitize($application['Student_Email']) ?>
                    </div>
                    <div>
                        <strong>Student Skills:</strong><br>
                        <span><?= sanitize($application['Student_Skills'] ?? 'None specified') ?></span><br>
                        <strong>Resume PDF:</strong> 
                        <?php if (!empty($application['Resume_Path'])): ?>
                            <a href="<?= get_base_url() . sanitize($application['Resume_Path']) ?>" target="_blank" style="font-weight: 600;">📄 Open Resume File</a>
                        <?php else: ?>
                            <span style="color: var(--danger-600);">No File Uploaded</span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Targeted Internship Info -->
            <div style="margin-bottom: 1.5rem;">
                <h4 style="font-size: 0.95rem; font-weight: 600; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 0.5rem;">Target Internship Opening</h4>
                <div style="font-size: 1.1rem; font-weight: 700; color: var(--primary-900);"><?= sanitize($application['Title']) ?></div>
                <div style="font-size: 0.9rem; color: var(--accent-600); font-weight: 600; margin-bottom: 0.5rem;">🏢 <?= sanitize($application['Company_Name']) ?></div>
                <div style="font-size: 0.85rem; color: var(--text-muted);">
                    <strong>Required Skills:</strong> <?= sanitize($application['Required_Skills']) ?>
                </div>
            </div>

            <hr style="border: none; border-top: 1px solid var(--border-color); margin: 1.5rem 0;">

            <!-- Mentor Form -->
            <form action="give_feedback.php?id=<?= $appId ?>" method="POST" data-validate>
                <div class="form-group">
                    <label class="form-label" for="status">Mentor Decision *</label>
                    <select id="status" name="status" class="form-select" required>
                        <option value="Approved" <?= $application['Status'] === 'Approved' ? 'selected' : '' ?>>👍 Approve (Forward to Company for Shortlisting)</option>
                        <option value="Mentor Review" <?= $application['Status'] === 'Mentor Review' ? 'selected' : '' ?>>⏳ Return to Student for Corrections</option>
                        <option value="Rejected" <?= $application['Status'] === 'Rejected' ? 'selected' : '' ?>>❌ Reject Application</option>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label" for="remarks">Written Remarks / Feedback *</label>
                    <textarea id="remarks" name="remarks" class="form-control" rows="4" placeholder="Provide constructive comments regarding the student's eligibility, skills alignment, or required resume updates..." required><?= sanitize($application['Remarks'] ?? '') ?></textarea>
                    <span class="form-text">These remarks will be visible to the student on their portal dashboard.</span>
                </div>

                <div style="display: flex; gap: 1rem; justify-content: flex-end; margin-top: 1.5rem;">
                    <a href="review_applications.php" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-primary">Save Decision & Remarks</button>
                </div>
            </form>

        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
