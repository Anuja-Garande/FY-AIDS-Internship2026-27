<?php
// faculty/dashboard.php - Faculty Mentor Dashboard
require_once __DIR__ . '/../config/db_connect.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_role('Faculty');
$user = get_logged_in_user();
$pdo = getDB();

// Count assigned students
$stmtAssigned = $pdo->prepare("SELECT COUNT(*) FROM Students WHERE Mentor_User_ID = ?");
$stmtAssigned->execute([$user['id']]);
$assignedCount = $stmtAssigned->fetchColumn();

// Count applications requiring mentor review
$stmtPending = $pdo->prepare("
    SELECT COUNT(*) 
    FROM Applications a
    JOIN Students s ON a.Student_ID = s.Student_ID
    WHERE s.Mentor_User_ID = ? AND a.Status IN ('Submitted', 'Mentor Review')
");
$stmtPending->execute([$user['id']]);
$pendingCount = $stmtPending->fetchColumn();

// Count approved applications
$stmtApproved = $pdo->prepare("
    SELECT COUNT(*) 
    FROM Applications a
    JOIN Students s ON a.Student_ID = s.Student_ID
    WHERE s.Mentor_User_ID = ? AND a.Status IN ('Approved', 'Shortlisted', 'Selected')
");
$stmtApproved->execute([$user['id']]);
$approvedCount = $stmtApproved->fetchColumn();

// Recent Pending Queue Items
$stmtQueue = $pdo->prepare("
    SELECT a.*, i.Title, c.Company_Name, u.Full_Name as Student_Name, s.Department, s.Resume_Path
    FROM Applications a
    JOIN Internships i ON a.Internship_ID = i.Internship_ID
    JOIN Companies c ON i.Company_ID = c.Company_ID
    JOIN Students s ON a.Student_ID = s.Student_ID
    JOIN Users u ON s.User_ID = u.User_ID
    WHERE s.Mentor_User_ID = ? AND a.Status IN ('Submitted', 'Mentor Review')
    ORDER BY a.Applied_Date ASC
    LIMIT 5
");
$stmtQueue->execute([$user['id']]);
$queueList = $stmtQueue->fetchAll();

$page_title = "Faculty Mentor Dashboard - SPPI Portal";
$active_page = "dashboard";
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
    <div>
        <h1 class="page-title">Welcome, Dr./Prof. <?= sanitize($user['name']) ?>! 👨‍🏫</h1>
        <p class="page-subtitle">Faculty Academic Mentor Portal & Student Verification Panel</p>
    </div>
    <div>
        <a href="review_applications.php" class="btn btn-primary">✅ Review Applications Queue (<?= $pendingCount ?>)</a>
    </div>
</div>

<!-- Metric Counters -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-content">
            <span class="stat-value"><?= $pendingCount ?></span>
            <span class="stat-label">Pending Reviews</span>
        </div>
        <div class="stat-icon warning">⏳</div>
    </div>

    <div class="stat-card">
        <div class="stat-content">
            <span class="stat-value"><?= $assignedCount ?></span>
            <span class="stat-label">Assigned Mentees</span>
        </div>
        <div class="stat-icon primary">👨‍🎓</div>
    </div>

    <div class="stat-card">
        <div class="stat-content">
            <span class="stat-value"><?= $approvedCount ?></span>
            <span class="stat-label">Approved Applications</span>
        </div>
        <div class="stat-icon success">👍</div>
    </div>
</div>

<!-- Pending Review Queue Card -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Pending Student Applications Needing Your Review</h3>
        <a href="review_applications.php" style="font-size: 0.85rem;">View Full Queue →</a>
    </div>
    <div class="card-body" style="padding: 0;">
        <?php if (empty($queueList)): ?>
            <div class="empty-state" style="border: none;">
                <div class="empty-state-icon">🎉</div>
                <div class="empty-state-title">Queue Clear</div>
                <p class="empty-state-desc">You have no pending student applications requiring approval at this moment.</p>
            </div>
        <?php else: ?>
            <div class="table-responsive" style="border: none;">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Student</th>
                            <th>Target Role & Company</th>
                            <th>Applied Date</th>
                            <th>Resume</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($queueList as $item): ?>
                            <tr>
                                <td>
                                    <strong><?= sanitize($item['Student_Name']) ?></strong><br>
                                    <span style="font-size: 0.8rem; color: var(--text-muted);"><?= sanitize($item['Department']) ?></span>
                                </td>
                                <td>
                                    <strong><?= sanitize($item['Title']) ?></strong><br>
                                    <span style="font-size: 0.8rem; color: var(--text-muted);"><?= sanitize($item['Company_Name']) ?></span>
                                </td>
                                <td style="font-size: 0.85rem; color: var(--text-muted);">
                                    <?= date('M d, Y', strtotime($item['Applied_Date'])) ?>
                                </td>
                                <td>
                                    <?php if (!empty($item['Resume_Path'])): ?>
                                        <a href="<?= get_base_url() . sanitize($item['Resume_Path']) ?>" target="_blank" class="btn btn-sm btn-outline">📄 View PDF</a>
                                    <?php else: ?>
                                        <span style="font-size: 0.8rem; color: var(--danger-600);">Missing</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?= render_status_badge($item['Status']) ?>
                                </td>
                                <td>
                                    <a href="give_feedback.php?id=<?= $item['Application_ID'] ?>" class="btn btn-sm btn-primary">Review & Decide</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
